#include "SplatIndirectIllumination.h"
#include "../PointCloudReader/PointCloudReader.h"
#include "../GlobalData/GlobalData.h"

using namespace iglu;

extern SGlobalData* g_data;


void SplatIndirectIllumination::Initialize( int trackNum )
{
}

void SplatIndirectIllumination::Display()
{

}

SplatIndirectIllumination::SplatIndirectIllumination() : IGLUDisplayMode()
{

}
