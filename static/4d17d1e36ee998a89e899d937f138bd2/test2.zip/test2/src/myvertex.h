//----------------------------------------------------------
// the definition of my FVF structure
//----------------------------------------------------------

//this struct is xyz + n + uv and has a constructor
#pragma once

struct MyVertex
{
	MyVertex(){}
	MyVertex(float x, float y, float z, 
		float nx, float ny, float nz, float u, float v)
	{
		 _x = x;   _y = y;   _z = z;
		_nx = nx; _ny = ny; _nz = nz;
		 _u = u;   _v = v;
	}

	float _x, _y, _z, _nx, _ny, _nz, _u, _v;
};
