//----------------------------------------------------------
// Some problem has come out when i use STL vector ;(
// Header for PathFind class	ver1.0
//----------------------------------------------------------
#pragma once

#include <vector>
#include <cassert>
#include <windows.h>
#include <cmath>
#include "Node.h"
#define WIN32_LEAN_AND_MEAN

//extern GameEngine*			g_pGame;
//----------------------------------------------------------
// Structure PathFind
//----------------------------------------------------------
struct PathFind
{
	std::vector<Node*>		OpenList;			//at the beginnig please clean the OpenList
	std::vector<Node*>		CloseList;
	bool								m_bFindOne;				// whether find one?
	Node*							m_pTarget;					//if found, it 's target
	Node*							m_pCurrent;					//this is used for Drawing ,not the A* related stuff
	//CONSTRUCTOR
public:
	PathFind() :OpenList(0),CloseList(0),
						m_bFindOne(false),m_pTarget(0),m_pCurrent(0){}
	//IMPORTANT METHOD
	void		FindPath( Node* pStart , Node* pTarget ,Node * Map );
	void		DrawPath(HDC hdc , int screenwidth, int screenheight);
	void		ResetAllList();
	void		ReSortOpenListElement(Node* pNode);
	bool		IsInCloseList (Node* pNode);										//left for future optimztion
	bool		IsOpenEmpty(){return OpenList.empty();}
	bool		IsCloseEmpty(){return CloseList.empty();}
	bool		IsInOpenList( Node* pNode );									//left for future optimztion
	void		AddtoCloseList ( Node* pNode );								
	void		AddtoOpenList( Node* pNode);
	void		ResetAll(){ResetAllList();m_bFindOne = false;m_pTarget = 0;m_pCurrent = 0;}
	bool		IsTargetFound() {return m_bFindOne ;}
};

