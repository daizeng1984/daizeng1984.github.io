
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "UBITEST.h"

//-----------------------------------------------------------------
// Game Engine Functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
  // Create the game engine
  g_pGame = new GameEngine(hInstance, TEXT("UBITEST"),
    TEXT("UBITEST"), NULL, NULL, GRIDWIDTH+SCREENOFFSET, GRIDWIDTH+BUTTONHEIGHT+SCREENOFFSET);
  if (g_pGame == NULL)
    return FALSE;

  // Set the frame rate
  g_pGame->SetFrameRate(30);

  // Store the instance handle
  g_hInstance = hInstance;

  return TRUE;
}

void GameStart(HWND hWindow)
{
  // Seed the random number generator
  srand(GetTickCount());
	// Create map node
  // Create the offscreen device context and bitmap
  g_hOffscreenDC = CreateCompatibleDC(GetDC(hWindow));
  g_hOffscreenBitmap = CreateCompatibleBitmap(GetDC(hWindow),
    g_pGame->GetWidth(), g_pGame->GetHeight());
  SelectObject(g_hOffscreenDC, g_hOffscreenBitmap);

  NewGame();
}

void GameEnd()
{
  // Cleanup the offscreen device context and bitmap
  DeleteObject(g_hOffscreenBitmap);
  DeleteDC(g_hOffscreenDC);  

  // Cleanup the game engine
  delete g_pGame;

}

void GameActivate(HWND hWindow)
{
}

void GameDeactivate(HWND hWindow)
{
}

void GamePaint(HDC hDC)
{
  //// Draw the background
  //g_pBackground->Draw(hDC);

  //// Draw the desert bitmap
  //g_pDesertBitmap->Draw(hDC, 0, 371);

  //// Draw the sprites
  //g_pGame->DrawSprites(hDC);

  //if (g_bDemo)
  //{
  //  // Draw the splash screen image
  //  g_pSplashBitmap->Draw(hDC, 142, 20, TRUE);

  //  // Draw the hi scores
  //  TCHAR szText[64];
  //  RECT  rect = { 275, 250, 325, 270};
  //  SetBkMode(hDC, TRANSPARENT);
  //  SetTextColor(hDC, RGB(255, 255, 255));
  //  for (int i = 0; i < 5; i++)
  //  {
  //    wsprintf(szText, "%d", g_iHiScores[i]);
  //    DrawText(hDC, szText, -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
  //    rect.top += 20;
  //    rect.bottom += 20;
  //  }
  //}
  //else
  //{
  //  // Draw the score
  //  TCHAR szText[64];
  //  RECT  rect = { 460, 0, 510, 30 };
  //  wsprintf(szText, "%d", g_iScore);
  //  SetBkMode(hDC, TRANSPARENT);
  //  SetTextColor(hDC, RGB(255, 255, 255));
  //  DrawText(hDC, szText, -1, &rect, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);

  //  // Draw the number of remaining lives (cars)
  //  for (int i = 0; i < g_iNumLives; i++)
  //    g_pSmCarBitmap->Draw(hDC, 520 + (g_pSmCarBitmap->GetWidth() * i),
  //      10, TRUE);

  //  // Draw the game over message, if necessary
  //  if (g_bGameOver)
  //    g_pGameOverBitmap->Draw(hDC, 170, 100, TRUE);
  //}
	//Draw grid
	for (int x = 0 ; x < MAPSIZE ; ++ x )
		for ( int y = 0 ; y < MAPSIZE ; ++ y )
			g_MapNode[x][y].DrawOnDC(hDC,GRIDWIDTH,GRIDWIDTH);
	g_PathFind.DrawPath(hDC,GRIDWIDTH,GRIDWIDTH);
	//Draw button
	DrawButton(hDC,GRIDWIDTH ,0, 0 ,TEXT("RESET"));
	DrawButton(hDC,GRIDWIDTH ,GRIDWIDTH - BUTTONWIDTH, 0 ,TEXT("START"));
	//Help text
	RECT  rect = { BUTTONWIDTH, GRIDWIDTH, GRIDWIDTH - BUTTONWIDTH, GRIDWIDTH + BUTTONHEIGHT };
	SetBkMode(hDC, TRANSPARENT);
    SetTextColor(hDC, RGB(255, 255, 255));
    DrawText(hDC, TEXT("Press F1 for HELP"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	if ( g_bHelper )
	{
		RECT  rect = { BUTTONWIDTH, GRIDWIDTH/2-3*BUTTONHEIGHT, GRIDWIDTH - BUTTONWIDTH, GRIDWIDTH/2 + 6*BUTTONHEIGHT };
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, RGB(255, 255, 0));
		DrawText(hDC, TEXT("You can put the blue by clicking LeftButton\n")TEXT("And you can drag your mouse with LeftButton \ndown to put blue block continuously.\nYou can reclick the blue block to cancel your put.\n")
												TEXT("You can put the red or green circle using RightButton.\nYou can cancel your put by reclick the grid with circle in\n")
												TEXT("And you can use the 2 green button below.\nSome finding may takes a short time.\nSo don't close it;)it's not bugs!"), -1, &rect, DT_CENTER);
	}

}

void GameCycle()
{

    // Obtain a device context for repainting the game
    HWND  hWindow = g_pGame->GetWindow();
    HDC   hDC = GetDC(hWindow);

    // Paint the game to the offscreen device context
    GamePaint(g_hOffscreenDC);

    // Blit the offscreen bitmap to the game screen
    BitBlt(hDC, 0, 0, g_pGame->GetWidth(), g_pGame->GetHeight(),
      g_hOffscreenDC, 0, 0, SRCCOPY);
	
    // Cleanup
    ReleaseDC(hWindow, hDC);
}

void HandleKeys()
{
	static bool down = false;
	if (KEY_UP(VK_F1))
	{
		down = false;
	}
	if (KEY_DOWN(VK_F1)&& !down)
		if ( g_bHelper )
		{
			down = true;
			g_bHelper = false;
		}
		else
		{
			down = true;
			g_bHelper = true;
		}
}

void MouseButtonDown(int x, int y, BOOL bLeft)
{
	// in the button field?
	if ( y> GRIDWIDTH) 
	{
		//handle the button info
		HandleButton( x, y);
		return ;
	}
	//computed?
	if (g_bComputed ) return ;

	// make sure it's in the grid field
	if ( x < 0 || x > GRIDWIDTH || y < 0 || y > GRIDWIDTH )
		return;

	int	_x = x*MAPSIZE/GRIDWIDTH; int	_y = y *MAPSIZE/GRIDWIDTH;
	int	status = g_MapNode[_x][_y].GetData();
	if (bLeft)
	{
		if ( status == GRIDEMPTY )
			g_MapNode[_x][_y].SetData(BLUEBLOCK);
		if ( status == BLUEBLOCK)
			g_MapNode[_x][_y].SetData(GRIDEMPTY);
	}
	else
	{
		if ( status == GRIDEMPTY )
		{
			if ( !g_RedPut )
			{
				g_MapNode[_x][_y].SetData(REDCIRCLE);
				g_RedPut  =true;
				g_pStart = &g_MapNode[_x][_y];
			}else if ( !g_GreenPut)
			{
				g_MapNode[_x][_y].SetData(GREENCIRCLE);
				g_pTarget = &g_MapNode[_x][_y];
				g_GreenPut = true;
			}
		}
		if ( status == GREENCIRCLE || status == REDCIRCLE )
		{
			g_MapNode[_x][_y].SetData(GRIDEMPTY);
			if (status == REDCIRCLE )
			{	g_RedPut = false; g_pStart = NULL; }
			if ( status == GREENCIRCLE )
			{	g_GreenPut = false; g_pTarget = NULL; }
		}
	}
//#define	 BLUEBLOCK				1
//#define	 REDCIRCLE				2
//#define	 GREENCIRCLE			3
//#define	 GRIDEMPTY				0
		

}

void MouseButtonUp(int x, int y, BOOL bLeft)
{
}

void MouseMove(int x, int y)
{
	if (y> GRIDWIDTH) 
	{
		//HandleButton( x, y);
		return ;
	}
	if (g_bComputed ) return ;
	// make sure it's in the grid field
	if ( x < 0 || x > GRIDWIDTH || y < 0 || y > GRIDWIDTH )
		return;
	int	_x = x*MAPSIZE/GRIDWIDTH; int	_y = y *MAPSIZE/GRIDWIDTH;
	int	status = g_MapNode[_x][_y].GetData();
	if ( KEY_DOWN(VK_LBUTTON) )
	{
		if ( status == GRIDEMPTY )
			g_MapNode[_x][_y].SetData(BLUEBLOCK);
		/*if ( status == BLUEBLOCK)
			g_MapNode[_x][_y].SetData(GRIDEMPTY);*/
	}

}

void NewGame(int	GameState)
{
	//intialize Node
	for (int x = 0 ; x < MAPSIZE ; ++ x )
		for ( int y = 0 ; y < MAPSIZE ; ++ y )
		{
			g_MapNode[x][y].InitializeNode( x , y );
			if ( GameState  == NOCLEANOFBLUEBLOCK)
				g_MapNode[x][y].ResetData();
			else
				g_MapNode[x][y].SetData(GRIDEMPTY);
			g_MapNode[x][y].SetZeroFGH();
			g_MapNode[x][y].SetParent(NULL);
		//if ( (x > 0) )
		//	g_MapNode[x][y].neighbour[0] = &g_MapNode[x -1][y];
		//else
		//	g_MapNode[x][y].neighbour[0] = 0;
		//if ( (y > 0) )
		//	g_MapNode[x][y].neighbour[1] =&g_MapNode[x ][y-1];
		//else
		//	g_MapNode[x][y].neighbour[1] = 0;
		//if ( (x < MAPSIZE-1) )
		//	g_MapNode[x][y].neighbour[2] = &g_MapNode[x +1][y];
		//else
		//	g_MapNode[x][y].neighbour[2] = 0;
		//if ( (y< MAPSIZE-1) )
		//	g_MapNode[x][y].neighbour[3] = &g_MapNode[x ][y+1];
		//else
		//	g_MapNode[x][y].neighbour[3] = 0;
		}
		g_PathFind.ResetAll();
		g_pStart = NULL;
		g_pTarget = NULL;
		g_RedPut = false;
		g_GreenPut = false;
		g_bComputed = false;


}


void	DrawButton( HDC hdc ,int	gridw ,int x , int y , TCHAR* szName)	// x ,y is the coordinate in the bottom
{
    RECT  rect = { x, gridw+y, x+BUTTONWIDTH, y+gridw + BUTTONHEIGHT };
	HBRUSH hGreen = ::CreateSolidBrush(RGB(0,255 ,0)),hOld;
	hOld = (HBRUSH)::SelectObject(hdc,(HBRUSH)hGreen );
	::Rectangle(hdc , x, gridw+y, x+BUTTONWIDTH, y+gridw + BUTTONHEIGHT );
	::SelectObject(hdc,hOld);
	::DeleteObject(hGreen);
	
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 0, 0));
    DrawText(hdc, szName, -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}
void	HandleButton( int x , int y )
{
	if ( x< BUTTONWIDTH )
	{
		static bool bNewGame = false;
		if (g_RedPut == false && g_GreenPut == false)
				bNewGame = true;
		if ( bNewGame == false)
		{
			
			NewGame(NOCLEANOFBLUEBLOCK);
			
		}
		else
		{
			NewGame(NORMAL);
			bNewGame = false;
		}
		g_bComputed = false;
		return ;
	}
	if ( x >GRIDWIDTH - BUTTONWIDTH )
	if (  !g_bComputed)
	{
		//g_pStart->h = abs( g_pTarget ->x - g_pStarts->x)*COSTPERBLOCK 
		//						+  abs( g_pTarget ->y - g_pStarts->y)*COSTPERBLOCK
		if (!g_pTarget ) 
		{
			::MessageBox(g_pGame->GetWindow(),TEXT("No GreenCircle!"),TEXT("Warning:"),0);
			return;
		}
		if (! g_pStart ) 
		{
			::MessageBox(g_pGame->GetWindow(),TEXT("No RedCircle!"),TEXT("Warning:"),0);
			return;
		}
		g_pStart->ComputeH(g_pTarget);
		g_PathFind.FindPath( g_pStart , g_pTarget, & g_MapNode[0][0] );
		if ( !g_PathFind.IsTargetFound() )
		::MessageBox(g_pGame->GetWindow(),TEXT("No Path Exist!"),TEXT("Warning:"),0);
		g_bComputed = true;
		return ;
	}
}