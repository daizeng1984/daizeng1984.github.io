//----------------------------------------------------------
// Source for Node
//----------------------------------------------------------
#include "Node.h"
//----------------------------------------------------------
//member function
//----------------------------------------------------------
void	Node::InitializeNode(int _x , int _y )
//this function initialize Node's neighbour info only
	{
		x = _x ;  y = _y;
		assert( (x >= 0) && (x < MAPSIZE)
			&&(y >= 0)&&(y < MAPSIZE) );
		//initialize neighbours
		if ( (x > 0) )
			neighbour[0] = this -MAPSIZE;
		else
			neighbour[0] = 0;
		if ( (y > 0) )
			neighbour[1] = this -1;
		else
			neighbour[1] = 0;
		if ( (x < MAPSIZE-1) )
			neighbour[2] = this  +MAPSIZE;
		else
			neighbour[2] = 0;
		if ( (y< MAPSIZE-1) )
			neighbour[3] = this +1;
		else
			neighbour[3] = 0;
	}

	void Node::ComputNeighbourFGH (int num ,Node* pTarget )//set the parent
		//this function compute the F G H of neighbour
	{
		//for ( int i = 0 ; i < NEIGHBOURNUM ; ++ i) 
			//if ( neighbour[i] ) 
		assert( neighbour[num] ) ;
		neighbour[num]->g =g +  COSTPERBLOCK ;

		neighbour[num]->ComputeH(pTarget);
			 
		 //neighbour[num]->parent = this ;
		 neighbour[num]->UpdateF();
	}
	bool Node::IsNeighbourGBetter(int num )
	{
		assert( neighbour[num] ) ;
		return neighbour[num]->g <( g +  COSTPERBLOCK); 
	}

	void		Node::ReComputeFGH(Node * pTarget) 
	{
		assert ( parent);
		g =parent->g +  COSTPERBLOCK ;
		h = ComputeH(pTarget);
		 UpdateF();
	}

	void		Node::DrawOnDC( HDC hdc , int screenwidth, int screenheight)
		//this function draw node on DC
	{
		//Draw Nodes
		::SelectObject(hdc,::GetStockObject(BLACK_PEN));
		::SelectObject(hdc,::GetStockObject(GRAY_BRUSH ) );
		::Rectangle(hdc,screenwidth*x/MAPSIZE, screenheight*y/MAPSIZE,
			screenwidth*(x+1)/MAPSIZE,screenheight*(y+1)/MAPSIZE);
		HBRUSH hRed,hBlue,hGreen,hOld;
		//::TextOut(hdc , g ,g,L"abc",4);///////////////////////////////////////////////////
		switch ( data )
		{
			case BLUEBLOCK:
				hBlue = ::CreateSolidBrush(RGB(0 ,0 ,255));
				hOld = (HBRUSH)::SelectObject(hdc,(HBRUSH)hBlue );
				::Rectangle(hdc,screenwidth*x/MAPSIZE, screenheight*y/MAPSIZE,
					screenwidth*(x+1)/MAPSIZE,screenheight*(y+1)/MAPSIZE);
				::SelectObject(hdc,hOld);
				::DeleteObject(hBlue);
				break;
			case REDCIRCLE:
				hRed = ::CreateSolidBrush(RGB(255 ,0 ,0)) ;
				hOld = (HBRUSH)::SelectObject(hdc,(HBRUSH)hRed );
				::Ellipse(hdc,screenwidth*x/MAPSIZE, screenheight*y/MAPSIZE,
					screenwidth*(x+1)/MAPSIZE,screenheight*(y+1)/MAPSIZE);
				::SelectObject(hdc,hOld);
				::DeleteObject(hRed);
				break;
			case GREENCIRCLE:
				hGreen = ::CreateSolidBrush(RGB(0,255 ,0));
				hOld = (HBRUSH)::SelectObject(hdc,(HBRUSH)hGreen );
				::Ellipse(hdc,screenwidth*x/MAPSIZE, screenheight*y/MAPSIZE,
					screenwidth*(x+1)/MAPSIZE,screenheight*(y+1)/MAPSIZE);
				::SelectObject(hdc,hOld);
				::DeleteObject(hGreen);
				break;
		}
	}
	//constructor should be written well
