
#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include <windows.h>
#include "GameEngine.h"
#include "Node.h"
#include "PathFind.h"

#define		BUTTONHEIGHT						64
#define		BUTTONWIDTH						128
#define		SCREENOFFSET						0
#define		GRIDWIDTH								640
#define		NOCLEANOFBLUEBLOCK					0
#define		NORMAL												1
//-----------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------
HINSTANCE         g_hInstance;
GameEngine*       g_pGame;
HDC               g_hOffscreenDC;
HBITMAP           g_hOffscreenBitmap;

Node				g_MapNode[MAPSIZE][MAPSIZE];
PathFind			g_PathFind;								//it contain OPEN & CLOSE LIST for a*
Node*				g_pStart = NULL,*g_pTarget = NULL;
bool					g_RedPut = false;
bool					g_GreenPut = false;
bool					g_bComputed = false;
bool					g_bHelper = false;
//RECT				g_rReset, g_r
//-----------------------------------------------------------------
// Function Declarations
//-----------------------------------------------------------------
void NewGame(int	iGameState = NORMAL);
void	DrawButton( HDC hdc ,int	gridw ,int x , int y , TCHAR* szName);
void	HandleButton( int x , int y );
