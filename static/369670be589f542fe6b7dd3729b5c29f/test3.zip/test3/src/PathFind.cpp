//----------------------------------------------------------
// Source for PathFind class
// DEC 17 ver 1.0 AI for UBITEST
// by DaveDzeng
//----------------------------------------------------------
# include "PathFind.h"
//member function
//----------------------------------------------------------
//----------------------------------------------------------
// Extern DEC 17 9pm
//----------------------------------------------------------
extern	bool		g_GreenPut;
void PathFind::AddtoOpenList( Node* pNode)
//add node's pointer to OpenList
{
	//Add to OpenList by F order DEC 17 8pm
	assert( pNode );
	std::vector<Node*>::iterator itr;
	if ( OpenList.empty()){OpenList.push_back( pNode);return;}
	else
	for (  itr =  OpenList.begin() ; itr != OpenList.end() ; itr ++ )
	{
		if ( pNode ->f  > (*itr)->f )
		{
			OpenList.insert(itr, pNode );
			return;
		}
	}
	OpenList.push_back(pNode);
}
void PathFind::AddtoCloseList ( Node* pNode )
//similar to AddtoOpenList
{
	//Add to CloseList NO order
	assert(pNode);
	CloseList.push_back( pNode);
}
bool PathFind::IsInOpenList( Node* pNode )
{
	//whether pNode is in the Openlist
	//Using vector's method may be better.
	// but now i'm too frighten by vector.so just use it in a plain way
	assert( pNode );
	if ( OpenList.empty())return false;
	else
		for (DWORD i = 0 ; i < OpenList.size() ; ++i )
			if ( pNode  == OpenList[i] )return true;
	return false;
}

bool PathFind::IsInCloseList (Node* pNode)
{
	assert( pNode );
	if ( CloseList.empty())return false;
	else
		for (DWORD i = 0 ; i < CloseList.size() ; ++i )
			if ( pNode  == CloseList[i] )return true;
	return false;
}
void PathFind::ReSortOpenListElement(Node* pNode)
{
	//ReSort the element in the list,it should be in the list
	//The commented code is USELESS now! sojust pass it
	std::vector<Node*>::iterator itr;
	//bool deleted = false;
	//bool inserted = false;
	//use find_if function may save some time?
	if ( OpenList.empty()) return;
	
	for (itr =  OpenList.begin() ; itr !=OpenList.end() ; itr ++ )
	{
		//if ( pNode ->f  > (*itr).f && !inserted )
		//{
		//	OpenList.insert(itr, *pNode );
		//	itr ++;
		//	inserted = true;
		//	if (!deleted)continue;
		//	else return;
		//}
		if (  pNode  == (*itr)) /*&& !deleted)*/
		{
			OpenList.erase(itr);
			AddtoOpenList(pNode);
			//itr--;
			//deleted = true;
			//if ( !inserted) continue;
			//else 
			return;
		}
	}
	
}
void		PathFind::ResetAllList()
{
	OpenList.clear();
	CloseList.clear();
}
void		PathFind::DrawPath(HDC hdc , int screenwidth, int screenheight)
{
	//Draw Path if find one
	if ( !m_bFindOne ) return ;
	assert ( m_pTarget);
	assert ( m_pCurrent);
	Node*		current  = m_pTarget;
	Node*		back = NULL;
	HPEN hpen =::CreatePen(PS_SOLID, 5,RGB(255,255,0)) , hold;
	hold = (HPEN)::SelectObject(hdc,hpen);
	while ( current->GetParent() )
	{
		// draw line from current to it's parent
		::MoveToEx(hdc , current->x*screenwidth/MAPSIZE + screenwidth/MAPSIZE/2, 
									current->y*screenwidth/MAPSIZE + screenwidth/MAPSIZE/2 ,NULL);
		// draw line
		::LineTo(hdc, current->GetParent()->x*screenwidth/MAPSIZE + screenwidth/MAPSIZE/2, 
								current->GetParent()->y*screenwidth/MAPSIZE + screenwidth/MAPSIZE/2 );
		back = current;
		current = current->GetParent();
	}
	/*m_pCurrent = m_pCurrent->GetParent();*/
	// Move Nodes
	if ( back )
	{
			back ->SetParent(NULL);
			/*if (current ->GetData() == GREENCIRCLE)
			g_GreenPut = false;*/
			back ->SetData(current ->GetData());
			current ->SetData(GRIDEMPTY);
	}
	::SelectObject(hdc,hold);
	::DeleteObject(hpen);
}
void		PathFind::FindPath( Node* pStart , Node* pTarget ,Node * Map )
{
	//This is the CORE of A* algorithm ,and it totally comes from the WEB in
	//http://www.policyalmanac.org/games/aStarTutorial.htm 
	//Just ignore the commented code
	m_bFindOne = false;
	assert(pStart);
	assert(pTarget);
	Node* pCurrentNode = pStart;
	AddtoOpenList(pStart);
	while(true)
	{
		
		//get element from OpenList
		pCurrentNode = OpenList[OpenList.size()-1];
		OpenList.pop_back();
		//AddtoCloseList
		/*if ( pCurrentNode == pTarget)
			{	m_bFindOne = true;
			m_pTarget = pTarget;
			return;}*/
		AddtoCloseList(pCurrentNode);
		 //for each 4 neighboour nodes adjacent to the current node
		for ( int i = 0 ; i < NEIGHBOURNUM ; ++ i )
		{
			//If it is not walkable or if it is on the closed list, ignore it
			if ( !(pCurrentNode->GetNeighbour(i)) || 
				!(pCurrentNode->GetNeighbour(i)->IsWalkable())||
				IsInCloseList(pCurrentNode->GetNeighbour(i)) )
				continue;
			else//If it isn��t on the open list, add it to the open list. 
				//Make the current square the parent of this square. 
				//Record the F, G, and H costs of the square.
			{
				if (!IsInOpenList(pCurrentNode->GetNeighbour(i)))
					{
						pCurrentNode->ComputNeighbourFGH(i,pTarget);
						pCurrentNode->GetNeighbour(i)->SetParent(pCurrentNode);
						AddtoOpenList(pCurrentNode->GetNeighbour(i));
						continue;
					}
				else /*::MessageBox(g_pGame->GetWindow(),L"aa",L"aa",0);debugleft*/
					//If it is on the open list already, check to see if this path to that square is better
					if( !pCurrentNode->IsNeighbourGBetter(i) )
					{
						pCurrentNode->GetNeighbour(i)->SetParent(pCurrentNode);
						pCurrentNode->GetNeighbour(i)->ReComputeFGH(pTarget);
						ReSortOpenListElement(pCurrentNode->GetNeighbour(i));
					}
			}//end of if
		}//end for

		//Stop when 
		if ( IsInCloseList(pTarget) )
		{	m_bFindOne = true;
			m_pTarget = pTarget;
			m_pCurrent =pTarget;
			return ;}
		//FIND!
		if ( IsOpenEmpty() )
			return ;
		//NO FINDS!
		

	}

}