//----------------------------------------------------------
// Headre for Node
//----------------------------------------------------------
#pragma once
//----------------------------------------------------------
// Include Files
//----------------------------------------------------------
#include <cassert>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cmath>
//----------------------------------------------------------
// Macro and Constant
//----------------------------------------------------------
#define NEIGHBOURNUM        4
#define MAPSIZE					64
#define	 BLUEBLOCK				1
#define	 REDCIRCLE				2
#define	 GREENCIRCLE			3
#define	 GRIDEMPTY				0
#define	 COSTPERBLOCK			10
//----------------------------------------------------------
// Node structure
//----------------------------------------------------------
struct Node//when initialize the children should be ready
{
	int	f, g, h ;												//it shouldn be initialize to zero until we set to find
	Node*	parent;
	//--------------------------------------------------------------
	int	x,y;													//unchanged in finding path
	Node* neighbour[NEIGHBOURNUM];	//neighbour UNCHANGED
	int	data;													//whethr it is a obstacle ,we never change it once intialized.
	//----------------------------------------------------------
	//CONSTRUCTOR
	//----------------------------------------------------------
	Node() :f(0),g(0),h(0),data(0),parent(NULL){}
	//----------------------------------------------------------
	//SET & GET
	bool		IsWalkable() { if ( data == BLUEBLOCK) return false; else return true;}
	void		SetParent(Node * p ) { parent = p;}
	bool		IsNeighbourValid( int neighbourId)
	{//assert(children[childId]);return (bool)neighbour[neighbourId];
		//if ( children[]
		//if ( (children[childId]->x >= 0) && (children[childId]->x < MAPSIZE)
		//	&&(children[childId]->y >= 0)&&(children[childId]->y < MAPSIZE) )
		//	return true;
		//return false;
	}
	Node* GetNeighbour( int num ){return neighbour[num];}
	Node*	GetParent() {return parent;}
	void		SetData( int	type){data = type;}
	int		GetData() {return data;}
	void		SetZeroFGH() {g = h = f = 0;parent = 0;}
	//OTHER IMPORTANT METHOD
	void		UpdateF() {f = g+h;}
	int		ComputeH(Node * pTarget) {h = abs(x -pTarget->x)*COSTPERBLOCK 
																			+abs(y -pTarget->y)*COSTPERBLOCK;//may change
																				return h ;}
	void		InitializeNode(int _x , int _y );
	void		ResetData() {f= (0);g= (0);h=(0);parent=(NULL);if ( data == REDCIRCLE || data == GREENCIRCLE) data =0;}
	void		ComputNeighbourFGH (int num ,Node* pTarget );
	bool		IsNeighbourGBetter(int num );
	void		ReComputeFGH(Node * pTarget) ;
	void		DrawOnDC( HDC hdc , int screenwidth, int screenheight);
	
};



