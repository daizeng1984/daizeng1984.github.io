//-----------------------------------------------------------------
// SHIPOBJ class header 
//	Dec 10			ver1.0
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
# include "obj.h"
# include "EnemyObj.h"
# include <vector>
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------
#include "mymacro.h"
//-----------------------------------------------------------------
// OBJ Class
//-----------------------------------------------------------------
class ShipObj : public Obj
{
	int			m_iLife;						//Life
	int			m_iScore ;					//Score
	int			m_iTotalBullet;			//bullet
	int			m_iInvetDelay;			//USELESS for now DEC 17 3pm
public:
	ShipObj::ShipObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device );
	//void			ResetInvet () { m_iInvetDelay = MAXINVETDELAY ; }
	//GET & SET &ADD & IS
	int	GetLife ( ) {return m_iLife ;}
	void		SetLife (int n ) { m_iLife = n ;}
	int	GetScore () { return m_iScore;}
	void		SetScore(int n ) { m_iScore = n ;}
	void		KillLife (int n =1) { if ( m_iLife<=0 )m_iLife = 0;else m_iLife -= n ;}
	void		GainScore ( int n	=1) {m_iScore += n ;}		//..........
	void		DecrBullet () { if ( m_iTotalBullet> 0 ) m_iTotalBullet-- ; else m_iTotalBullet = 0;  }
	void		IncrBullet () { if (m_iTotalBullet <   MAXBULLET ){(++m_iTotalBullet);}}
	bool		CanFire () { if (m_iTotalBullet < MAXBULLET ) return true;
																else return false; }
	//UPDATE & DRAW
	virtual bool Update();
	virtual	bool		Update( EnemyObj* enemy[]);
	void		Balance () { if ( m_iTheta >0 ) SetTheta(m_iTheta-1);if( m_iTheta <0 ) SetTheta(m_iTheta+1) ;}
};

