//-----------------------------------------------------------------
// Obj Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "Obj.h"
#include "GameEngine.h" //for the Realease template 
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------

const float PI = 3.14159f;
//-----------------------------------------------------------------
//Function Implemenation
//-----------------------------------------------------------------

Obj::Obj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device ):m_Mtrls(0),m_Textures(0),
																										m_velocity(0.0f,0.0f,0.0f ),m_dying(false),
																										m_hidden(true),m_iBulk(20),
																										m_iDelayMax (MAXDIEDELAY) ,
																										m_iDelayTick (DIEDELAYTICK),
																										m_iHiddenDelay(MAXHIDDENDELAY),
																										Z(OBJZDEPTH),
																										m_iThetaMax (MAXTHETA )
{
	HRESULT hr = 0;

	//
	// Load the XFile data.
	//
	ID3DXMesh*  SourceMesh = 0;
	ID3DXBuffer* adjBuffer  = 0;
	ID3DXBuffer* mtrlBuffer = 0;
	DWORD        numMtrls   = 0;

	hr = D3DXLoadMeshFromX(  
		szXFilename,
		D3DXMESH_MANAGED,
		Device,
		&adjBuffer,
		&mtrlBuffer,
		0,
		&numMtrls,
		&SourceMesh);

	if(FAILED(hr))
	{
		::MessageBox(0, _T("D3DXLoadMeshFromX() - FAILED"), 0, 0);
		return ;
	}

	//
	// Extract the materials, load textures.
	//

	if( mtrlBuffer != 0 && numMtrls != 0 )
	{
		D3DXMATERIAL* mtrls = (D3DXMATERIAL*)mtrlBuffer->GetBufferPointer();

		for(DWORD i = 0; i < numMtrls; i++)
		{
			// the MatD3D property doesn't have an ambient value set
			// when its loaded, so set it now:
			mtrls[i].MatD3D.Ambient = mtrls[i].MatD3D.Diffuse;

			// save the ith material
			m_Mtrls.push_back( mtrls[i].MatD3D );

			// check if the ith material has an associative texture
			// HERE WE DON"T USE TEXTURE SO WE IGNORE IT DEC 17 3pm
			//if( mtrls[i].pTextureFilename != 0 )
			//{
			//	// yes, load the texture for the ith subset
			//	IDirect3DTexture9* tex = 0;
			//	D3DXCreateTextureFromFile(
			//		Device,
			//		mtrls[i].pTextureFilename,
			//		&tex);

			//	// save the loaded texture
			//	m_Textures.push_back( tex );
			//}
			//else
			{
				// no texture for the ith subset
				m_Textures.push_back( 0 );
			}
		}
	}
	Release<ID3DXBuffer*>(mtrlBuffer); // done w/ buffer

	//
	// Optimize the mesh.
	//

	hr = SourceMesh->OptimizeInplace(		
		D3DXMESHOPT_ATTRSORT |
		D3DXMESHOPT_COMPACT  |
		D3DXMESHOPT_VERTEXCACHE,
		(DWORD*)adjBuffer->GetBufferPointer(),
		(DWORD*)adjBuffer->GetBufferPointer(), // new adjacency info
		0, 0);

	if(FAILED(hr))
	{
		::MessageBox(0, _T("OptimizeInplace() - FAILED"), 0, 0);
		Release<ID3DXBuffer*>(adjBuffer); // free
		return ;
	}

	//
	// Generate the progressive mesh. 
	//

	hr = D3DXGeneratePMesh(
		SourceMesh,
		(DWORD*)adjBuffer->GetBufferPointer(), // adjacency
		0,                  // default vertex attribute weights
		0,                  // default vertex weights
		1,                  // simplify as low as possible
		D3DXMESHSIMP_FACE,  // simplify by face count
		&m_PMesh);

	Release<ID3DXMesh*>(SourceMesh);  // done w/ source mesh
	Release<ID3DXBuffer*>(adjBuffer); // done w/ buffer

	if(FAILED(hr))
	{
		::MessageBox(0, _T("D3DXGeneratePMesh() - FAILED"), 0, 0);
		return ;
	}

	// set to original detail
	/*DWORD m_maxFaces = m_PMesh->GetMaxFaces();*/
	m_iFaces = m_PMesh->GetNumFaces();
	m_PMesh->SetNumFaces(m_iFaces+800);
	//-------------------------------------------------------------
	// End of PMESH Initialization
	//-------------------------------------------------------------
	ComputeBoundingBox( );
	ResetMatrix ();
	SetPosition( 0.0f , 0.0f );
}
Obj::Obj() :m_Mtrls(0),m_Textures(0),
				m_velocity(0.0f,0.0f,0.0f ),m_dying(false),
				m_hidden(true),m_iBulk(20),
				m_iDelayMax (255) ,m_iHiddenDelay(20),		
				Z(150.0f)
{}
//Obj::Obj(Obj& obj ):m_PMesh(PMesh) ,m_Mtrls(0),m_Textures(0),
//																										m_Position.x(0.0f), m_Position.y(0.0f), 
//																										m_velocity(1.0f),m_dying(false),m_hidden(true)
//{
//	if ( &obj == this ) return ;
//
//}
bool		Obj::ComputeBoundingBox( ) // return bounding box
{
	HRESULT hr = 0;
	BYTE* v = 0;
	m_PMesh->LockVertexBuffer(0, (void**)&v);
	hr = D3DXComputeBoundingBox(
	(D3DXVECTOR3*)v,
	m_PMesh->GetNumVertices(),
	D3DXGetFVFVertexSize(m_PMesh->GetFVF()),
	&m_min,
	&m_max);
	m_PMesh->UnlockVertexBuffer();
	if( FAILED(hr) )
	return false;
	m_min = m_min*m_iBulk;;
	m_max = m_max*m_iBulk;
	return true;
}
bool		Obj::Draw ( IDirect3DDevice9*	Device ) 
{
	//check device
	if ( !Device ) return false ;
	if ( m_hidden )		return true;
	// need to blend ?
	if ( m_dying )
	{
		Device->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
		Device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
		Device->SetTextureStageState(0, D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
		// set blending factors so that alpha
		// component determines transparency
		Device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		Device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
		Device->SetTransform(D3DTS_WORLD, &m_WorldMatrix);
		for(DWORD i = 0; i < m_Mtrls.size(); i++)
			{
				m_Mtrls[i].Diffuse.a = GetAlpha();
				// draw pmesh
				Device->SetMaterial( &m_Mtrls[i] );
				Device->SetTexture(0, m_Textures[i]);
				m_PMesh->DrawSubset(i);
			}
		Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
		return true ;
	}
	else
	{
		//Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
		Device->SetTransform(D3DTS_WORLD, &m_WorldMatrix);
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		////////////////////		D3DXMATRIX Rx, Ry;

		////////////////////// rotate 60 degrees on x-axis
		////////////////////

		////////////////////// incremement y-rotation angle each frame
		////////////////////static float y = 0.0f;
		////////////////////D3DXMatrixRotationY(&Ry, y);
		////////////////////y += 0.01f;

		////////////////////// reset angle to zero when angle reaches 2*PI
		////////////////////if( y >= 6.28f )
		////////////////////	y = 0.0f;

		////////////////////// combine x- and y-axis rotation transformations.
		////////////////////D3DXMATRIX p =  Ry;

		////////////////////Device->SetTransform(D3DTS_WORLD, &p);
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		for(DWORD i = 0; i < m_Mtrls.size(); i++)
			{
				// draw pmesh
				Device->SetMaterial( &m_Mtrls[i] );
				Device->SetTexture(0, m_Textures[i]);
				m_PMesh->DrawSubset(i);
			}
		//should maintain a global matrix to restore the status
		//--------------------------------------------------------------
		return true ;
	}

	return true;
}
bool		Obj::Update ()
{
	UpdateMatrix();
	return true ;
}
void	Obj::UpdateMatrix ()
{	
	// THIS FUNCTION MAY BE OPTIMIZED ,BUT RIGHT NOW IT'S NOT PROPER TO DO IT
	//SET ASIDE FOR LATER
	//s matrix
	D3DXMATRIX		Scale;	
	if ( m_iBulk ) D3DXMatrixScaling(	&Scale, // Result.
																m_iBulk, // Number of units to scale on the x-axis.
																m_iBulk, // Number of units to scale on the y-axis.
																m_iBulk // Number of units to scale on the z-axis.
																);
	else D3DXMatrixIdentity( &Scale );
	//r matrix
	D3DXMATRIX		Rotate;
	if ( m_iTheta ) D3DXMatrixRotationX( &Rotate , (float)m_iTheta/180.0f*PI);
	else	D3DXMatrixIdentity( &Rotate );

	//t
	D3DXMATRIX		Translate;
		m_Position.x += m_velocity.x ;
		m_Position.y += m_velocity.y ;
		D3DXMatrixTranslation(	&Translate, m_Position.x, m_Position.y,Z );
		/*D3DXMatrixTranslation(	&Translate, 0, 0,Z );*/

	/*m_WorldMatrix = (((m_LocalMatrix * Scale) * Rotate) * Translate); */
		m_WorldMatrix =  m_LocalMatrix *Rotate *Scale* Translate ;

}
bool		Obj::IsHitted(Obj *ptrObj) // this target
{
	if ( ptrObj->IsDying() || ptrObj->IsHidden() ) return 0;
	float x1 =  m_Position.x+m_min.x*(MAXBOUNDMULTIPLIER)  ; 
	float x2 = m_Position.x + m_max.x *(MAXBOUNDMULTIPLIER) ;
	float y1 = m_Position.y + m_min.y*(MAXBOUNDMULTIPLIER) ; 
	float y2 = m_Position.y + m_max.y *(MAXBOUNDMULTIPLIER);
	float _x1 = ptrObj->GetPositionX() +ptrObj->GetBoxMin()->x *(MAXBOUNDMULTIPLIER); 
	float _x2 = ptrObj->GetPositionX() + ptrObj->GetBoxMax()->x *(MAXBOUNDMULTIPLIER);
	float _y1 = ptrObj->GetPositionY() +ptrObj->GetBoxMin()->y*(MAXBOUNDMULTIPLIER) ; 
	float _y2 = ptrObj->GetPositionY() + ptrObj->GetBoxMax()->y *(MAXBOUNDMULTIPLIER);
	if ( ( MAX(x1,x2 ) >MIN(_x1,_x2 ))
			&&( MAX(_x1,_x2 ) >MIN(x1,x2 ))
			&&( MAX( y1, y2) >MIN( _y1, _y2))
			&&( MAX( _y1, _y2) >MIN(y1, y2 )))
	return true;
	else return false;
	return 0;
}

