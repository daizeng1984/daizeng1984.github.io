//-----------------------------------------------------------------
// BackDrop Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "Animation.h"
#include "GameEngine.h" //for the Realease template 

//const DWORD BackDrop::Vertex::FVF = D3DFVF_XYZ |  D3DFVF_TEX1;
extern GameEngine*       g_pGame;
//-----------------------------------------------------------------
// Function Implementations
//-----------------------------------------------------------------
Animation::Animation(LPTSTR szFilename  , IDirect3DDevice9*	Device ,
					float fWidth , float fHeight ,float fDepth,int WidthNum,int HeightNum,int MaxFrame)
					:BackDrop(szFilename  , Device ,
					fWidth , fHeight ,fDepth),m_iWidthNum(WidthNum),m_iHeightNum(HeightNum),
					m_iMaxDelay(ANIMATION_MAXFRAMEDELAY)
{
	m_iMaxFrame = MaxFrame;						//Maxframe <= Width*HeightNum
	m_iCurFrame = 0;
	m_iCycles = 1;								//-1 is endless cycles,default is 1
	m_iFrameDelay = m_iMaxDelay;						//
	m_bHidden = true;
}
void Animation::Draw(IDirect3DDevice9 *Device)
{
	//Hidden ?
		if ( m_bHidden) return ;
	//Not Hidden!
		D3DXMATRIX		matTexture;
		D3DXMatrixIdentity( &matTexture );
		matTexture._11 = 1.0f / (float)m_iWidthNum;
		matTexture._22 = 1.0f / (float)m_iHeightNum;
		int	x = (m_iCurFrame%m_iWidthNum);
		int	y = (m_iCurFrame/m_iWidthNum) ;
		matTexture._31 =  (float)x* matTexture._11;
		matTexture._32 =  (float)y* matTexture._22;
		//enable blending
		Device->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
		Device->SetRenderState(D3DRS_ZENABLE, false);
		
		Device->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		Device->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);

		BackDrop::Draw(Device,matTexture);
		Device->SetRenderState(D3DRS_ZENABLE, true);
		Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
		Device->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		 /*World matrix has been set to eye ,so don't worry about this DEC 17 3pm*/
		/*Device->SetTransform(D3DTS_TEXTURE0 , &world );*/
}

void Animation::Update()
{
	//Cycle = -1 may need logic but in this demo ,just forget about i t!
	if ( m_bHidden || (m_iCycles == 0) )
		return;
		if ( m_iFrameDelay -- <= 0 )
		{
			m_iFrameDelay =m_iMaxDelay;
			if ( ++ m_iCurFrame > m_iMaxFrame) 
			{
				m_iCurFrame = 0 ;
				--m_iCycles;
				if ( m_iCycles == 0 )
					m_bHidden = true;
			}
		}
}