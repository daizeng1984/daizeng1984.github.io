//-----------------------------------------------------------------
// ENEMYOBJ class header 
//	Dec 10			ver1.0
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "mymacro.h"
# include "d3d9.h"
# include "Obj.h"
# include <vector>
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// EnemyObj Class
//-----------------------------------------------------------------
class EnemyObj : public Obj
{
	static	int	iTotalEnemy ;		//MAY SEEM USELESS BUT 
													//IF YOU WANNA CONTROL ENEMY IN RUMTIME,
													//THING WILL BE DIFFERENT
	static	int	iTotalBullet ;		//DEC 17 2pm I reread the document find this needs
	int				m_iTotalBullet;
	int				m_iHiddenMax;
public:
	EnemyObj::EnemyObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device, int iHidden = MAXHIDDENDELAY );
	EnemyObj::~EnemyObj() {  }//copy constructor should use this method
	// INCR & DECR & CAN
	static	void		IncrEnemy() { if ( iTotalEnemy < MAXENEMY ) (++iTotalEnemy);}
	static	void		DecrEnemy() { if ( iTotalEnemy> 0 ) iTotalEnemy-- ; else iTotalEnemy = 0;  }
	void		IncrBullet () { if (m_iTotalBullet <   MAXENEMYBULLET )
														++m_iTotalBullet;
										if (iTotalBullet <   TOTALMAXENEMYBULLET )
														++iTotalBullet;	}
	void		DecrBullet () { if ( m_iTotalBullet > 0 ) m_iTotalBullet-- ; else m_iTotalBullet = 0; 
										if ( iTotalBullet > 0 ) iTotalBullet-- ; else iTotalBullet = 0;  }
	//bool		CanFire () { if (m_iTotalBullet <MAXENEMYBULLET ) return true;
	//															else return false; }
	bool		CanFire () { if ((m_iTotalBullet <MAXENEMYBULLET) 
										&& (iTotalBullet <TOTALMAXENEMYBULLET)) return true;
									else return false; }
	static	bool		CanReappear() { if ( iTotalEnemy < MAXENEMY )  return true;
																else return false;}
	//UPDATE 
	virtual bool		Update(int enemyid);
};


