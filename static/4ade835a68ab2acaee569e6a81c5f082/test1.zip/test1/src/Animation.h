//-----------------------------------------------------------------
// BackDrop class header 
//	Dec 10			ver1.0
//  This class is used to implement the keyframe animation
//	It inherit from BackDrop
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "mymacro.h"
#include "BackDrop.h"
# include "d3dx9.h"
//-----------------------------------------------------------------
// Animation Class
//-----------------------------------------------------------------

class Animation : public BackDrop
{
	int		m_iWidthNum,m_iHeightNum;
	int		m_iMaxFrame;						//Maxframe <= Width*HeightNum
	int		m_iCurFrame;
	int		m_iCycles;								//-1 is endless cycles
	int		m_iFrameDelay;						//
	int		m_iMaxDelay;
	bool		m_bHidden;
public:
	Animation(LPTSTR szFilename  , IDirect3DDevice9*	Device ,
					float fWidth , float fHeight ,float fDepth,int WidthNum,int HeightNum,int MaxFrame);
	~Animation(){}
	//Reload Draw and Add Update Method

	void		Draw ( IDirect3DDevice9*	Device );
	void		Update();
	void		SetDelayPerFrame(int		n) {m_iMaxDelay = n;}
	void		InitializeFrame() {m_iCurFrame = 0;m_iCycles = 1;m_iFrameDelay = m_iMaxDelay;SetHidden(false);}
	void		SetHidden(bool b) {m_bHidden = b;}
	bool		IsHidden() {return m_bHidden;}
	//void		SetPosition ( float x , float y )
	//{

	//}
};
