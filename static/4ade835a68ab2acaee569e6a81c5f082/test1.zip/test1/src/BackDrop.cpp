//-----------------------------------------------------------------
// BackDrop Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "BackDrop.h"
#include "GameEngine.h" //for the Realease template 

const DWORD BackDrop::Vertex::FVF = D3DFVF_XYZ |  D3DFVF_TEX1;
extern GameEngine*       g_pGame;
//-----------------------------------------------------------------
// Function Implementations
//-----------------------------------------------------------------
BackDrop::BackDrop ( LPTSTR szFilename  , IDirect3DDevice9*	Device ,
					float fWidth , float fHeight ,float fDepth)
					: m_fWidth(fWidth), m_fHeight(fHeight),m_fDepth(fDepth),m_Position(0.0f, 0.0f, 0.0f),
					m_u(0.0f) , m_v(0.0f) ,m_ChangeDelay(MAXBKDROPCHANGE) ,
					m_step(CHANGESTEPINITIAL)
{
	// THE CODE BELOW COMES FROM FRANK LUNA'S DX9 BOOKS
	// Begging introduction to direct x 9 books
		
		Device->CreateVertexBuffer(
		6 * GetSizeofVertex(), 
		D3DUSAGE_WRITEONLY,
		Vertex::FVF,
		D3DPOOL_MANAGED,
		&(m_BackDrop),
		0);

	Vertex* v;
	m_BackDrop->Lock(0, 0, (void**)&v, 0);

	// m_BackDrop built from two triangles, note texture coordinates:
	v[0] = Vertex(-fWidth/2.0f, -fHeight/2.0f,  fDepth, 0.0f, 1.0f);
	v[1] = Vertex(-fWidth/2.0f,  fHeight/2.0f,  fDepth, 0.0f, 0.0f);
	v[2] = Vertex( fWidth/2.0f,  fHeight/2.0f,  fDepth,  1.0f, 0.0f);

	v[3] = Vertex(-fWidth/2.0f, -fHeight/2.0f,  fDepth,  0.0f, 1.0f);
	v[4] = Vertex( fWidth/2.0f,  fHeight/2.0f,  fDepth,   1.0f, 0.0f);
	v[5] = Vertex( fWidth/2.0f, -fHeight/2.0f,  fDepth,   1.0f, 1.0f);

	m_BackDrop->Unlock();

	//
	// Create the texture and set filters.
	//

	//D3DXCreateTextureFromFile(
	//	Device,
	//	szFilename,
	//	&m_Tex);
	// to use color key!!!

	D3DXCreateTextureFromFileEx(
		Device,
		szFilename,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		NULL,
		D3DFMT_A8R8G8B8,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		D3DCOLOR_XRGB(255,0,255),	//HOT PINK
		NULL,
		NULL,
		&m_Tex);

}

BackDrop::~BackDrop()
{
	Release(m_BackDrop);
	Release(m_Tex);
}

void BackDrop::Draw ( IDirect3DDevice9*	Device )
{
		Device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		Device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
		Device->SetRenderState(D3DRS_LIGHTING, false);
		//---------------------------------------------restore???????????????
		// I ll use no texture so needn't to restore.just leavei t DEC17 3pm
		D3DXMATRIX		world;	
		D3DXMatrixIdentity( &world );
		D3DXMATRIX		matTexture;
		D3DXMatrixIdentity( &matTexture );
		matTexture._31 = ( m_u += m_step );			//cost a lot of energy here ;( just transformation of TEXTURE coordinates
		if ( m_u >2.0f ) m_u = 1.0f;
		Device->SetTransform(D3DTS_TEXTURE0, &matTexture);   
		Device->SetTextureStageState(0,   D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2 ); 
		Device->SetTransform(D3DTS_WORLD, &world);
		Device->SetTransform(D3DTS_PROJECTION, g_pGame->GetProj());
		Device->SetTexture(0, m_Tex);
		Device->SetStreamSource(0, m_BackDrop, 0, sizeof(Vertex));
		Device->SetFVF(Vertex::FVF);
		
		Device->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 2);
		Device->SetRenderState(D3DRS_LIGHTING, true);
		Device->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, 
                                 D3DTTFF_DISABLE );
		// World matrix has been set to eye ,so don't worry about this DEC 17 3pm
		/*Device->SetTransform(D3DTS_TEXTURE0 , &world );*/
}

void BackDrop::Draw ( IDirect3DDevice9*	Device ,D3DXMATRIX		matTexture)
{
	
		Device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		Device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
		Device->SetRenderState(D3DRS_LIGHTING, false);
		//---------------------------------------------restore???????????????
		// I ll use no texture so needn't to restore.just leavei t DEC17 3pm
		
		D3DXMATRIX		world;	
		D3DXMatrixIdentity( &world );
		D3DXMatrixTranslation(	&world, m_Position.x, m_Position.y,0);
		/*D3DXMatrixTranslation(	&world, 1.0f, 30.0f,0);*/

		Device->SetTransform(D3DTS_TEXTURE0, &matTexture);   
		Device->SetTextureStageState(0,   D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2 ); 
		Device->SetTransform(D3DTS_WORLD, &world);
		Device->SetTransform(D3DTS_PROJECTION, g_pGame->GetProj());
		Device->SetTexture(0, m_Tex);
		Device->SetStreamSource(0, m_BackDrop, 0, sizeof(Vertex));
		Device->SetFVF(Vertex::FVF);
		
		Device->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 2);
		Device->SetRenderState(D3DRS_LIGHTING, true);
		Device->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, 
                                 D3DTTFF_DISABLE );
		// World matrix has been set to eye ,so don't worry about this DEC 17 3pm
		D3DXMatrixIdentity( &world );
		Device->SetTransform(D3DTS_WORLD, &world);
		Device->SetTransform(D3DTS_TEXTURE0 , &world );
}

