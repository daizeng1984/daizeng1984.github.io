//-----------------------------------------------------------------
// ShipObj Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "ShipObj.h"
//#include "GameEngine.h" //for the Realease template 
void	Bombard(float x , float y );
//-----------------------------------------------------------------
//Function Implemenation
//-----------------------------------------------------------------
ShipObj::ShipObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device ) 
								: m_iLife(MAXLIFE) , m_iScore(0),Obj(szXFilename ,Device ),
								m_iTotalBullet(0)/* , m_iInvetDelay(MAXINVETDELAY)*/
{}
bool		ShipObj::Update()
{
	// dying means the Obj is becoming transparent gradually
	// hidden means hidden and dead
	if ( (!m_dying ) && (!m_hidden ) )
	{
		
		UpdateMatrix();
		//ship will balance himself
		// the theta will not exceed the max,because set function should not accept this value.
		Balance();
		return 1;
	}
	else if ( m_dying ) 
	{
		// control semi-transparency
		m_iDieDelay -= m_iDelayTick;
		//check if m_iDieDelay is minus!!
		if ( m_iDieDelay < 0 ) {
			m_iDieDelay = m_iDelayMax;
			m_dying = false ;
			m_hidden = true;
		}
		return 1;
	}
	else if ( m_hidden )		// it's a littel strange to name this var hidden( I don't know 
	{
		if ( m_iLife == 0 )
			//game is over!
			;
		else
		{
			--m_iLife; 
			m_dying = false ;
			m_hidden = false;
			//reset position as you did when game's bgining.
			//don't forget reset all the enemys
			
		}
		return 1;
	}
	return 1;
}
bool		ShipObj::Update( EnemyObj* enemy[])
{
	if ( (!m_dying ) && (!m_hidden ) )
	{
		for ( int i = 0 ; i < MAXENEMY ; ++i )
		{
			//if player collide enemy?
				if ( IsHitted(enemy[i]) ) 
				{
					//player die
					Die(true);
					KillLife();
					Bombard(GetPositionX(),GetPositionY());
					//enemy die
					enemy[i]->Die(true);
					Bombard(enemy[i]->GetPositionX(),enemy[i]->GetPositionY());
					// I add sounds, you may comment it if u don't like
					
					
					GainScore();
					return 1;
				}
		}
		UpdateMatrix();
		//ship will balance himself
		// the theta will not exceed the max,because set function should not accept this value.
		Balance();
		return 1;
	}
	else if ( m_dying ) 
	{
		m_iDieDelay -= m_iDelayTick;
		//check if m_iDieDelay is minus!!
		if ( m_iDieDelay < 0 ) {
			m_iDieDelay = m_iDelayMax;
			m_dying = false ;
			m_hidden = true;
			/*	--m_iLife;*/ 
		}
		return 1;
	}
	else if ( m_hidden )		// it's a littel strange to name this var hidden( I don't know 
	{
		if ( m_iLife == 0 )
			//game is over!
			;
		else
		{
			//reset position as you did when game's bgining.
			//don't forget reset all the enemys
			// NO NEED TO RESET ALL ENEMY FOR THIS DEMO DEC17 3pm ( i'm lazy;)
			
		}
		return 1;
	}
	return 1;
}