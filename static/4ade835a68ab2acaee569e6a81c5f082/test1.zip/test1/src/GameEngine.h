//-----------------------------------------------------------------
// Game Engine Object
// C++ Header - GameEngine.h
// Written by McMorrison
// Changed by Dave Dzeng(daizeng)
// I make a lot changes , hoping McMorrison would not be 
// angry! ;) and i add the initialization of Direct 3D, some code may
// come from FrankLuna's DX9 book
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <tchar.h>
//#include <vector>
#include <d3dx9.h> 
#include <cstring>
//using namespace std;
////-------------------------------------#include "Sprite.h"

//-----------------------------------------------------------------
// Windows Function Declarations
//-----------------------------------------------------------------
int WINAPI        WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow);
LRESULT CALLBACK  WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

//-----------------------------------------------------------------
// Game Engine Function Declarations
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance);
void GameStart(IDirect3DDevice9*		Device);
void GameEnd();
//void GameActivate(HWND hWindow);
//void GameDeactivate(HWND hWindow);
void GamePaint(HDC hDC);
void GameCycle();
void HandleKeys();
void MouseButtonDown(int x, int y, BOOL bLeft);
void MouseButtonUp(int x, int y, BOOL bLeft);
void MouseMove(int x, int y);
//BOOL SpriteCollision(Sprite* pSpriteHitter, Sprite* pSpriteHittee);
//void SpriteDying(Sprite* pSpriteDying);

//-----------------------------------------------------------------
// GameEngine Class
//-----------------------------------------------------------------
class GameEngine
{
protected:
  // Member Variables
  static GameEngine*  m_pGameEngine;
  HINSTANCE           m_hInstance;
  IDirect3DDevice9*		m_Device;		//DirectX's device obj
  IDirect3D9*					m_d3d9 ;
  D3DDEVTYPE				m_deviceType ;
  D3DXMATRIX				m_proj;			//other d3d stuff
   FLOAT							m_d3dfov;
   ID3DXFont*			m_pFont;			//font
  HWND                m_hWindow;
  TCHAR               m_szWindowClass[32];
  TCHAR               m_szTitle[32];
  WORD                m_wIcon, m_wSmallIcon;
  bool					m_bWindowed;
  int                 m_iWidth, m_iHeight;
  int                 m_iFrameDelay;
  BOOL                m_bSleep;			// may be deleted
  //UINT                m_uiJoystickID;
  //RECT                m_rcJoystickTrip;
  //vector<Sprite*>     m_vSprites;
  //UINT                m_uiMIDIPlayerID;

  // Helper Methods
  /*BOOL                CheckSpriteCollision(Sprite* pTestSprite);*/

public:
  // Constructor(s)/Destructor
          GameEngine(HINSTANCE hInstance, LPTSTR szWindowClass,
								 LPTSTR szTitle, bool bWindowed, 
								 int iWidth = 640, int iHeight = 480 , 
								 D3DDEVTYPE deviceType = D3DDEVTYPE_HAL,
								 FLOAT fov =D3DX_PI * 0.5f);
  virtual ~GameEngine();

  // General Methods
  static GameEngine*  GetEngine() { return m_pGameEngine; };
  BOOL                Initialize(int iCmdShow);
  LRESULT             HandleEvent(HWND hWindow, UINT msg, WPARAM wParam,
                        LPARAM lParam);
  void                ErrorQuit(LPTSTR szErrorMsg);
  //---------------------------------DEC 10 07
  //BOOL                InitJoystick();
  //void                CaptureJoystick();
  //void                ReleaseJoystick();
  //void                CheckJoystick();
  //void                AddSprite(Sprite* pSprite);
  //void                DrawSprites(HDC hDC);
  //void                UpdateSprites();
  //void                CleanupSprites();
  //Sprite*             IsPointInSprite(int x, int y);
  //void                PlayMIDISong(LPTSTR szMIDIFileName = TEXT(""),
  //                      BOOL bRestart = TRUE);
  //void                PauseMIDISong();
  //void                CloseMIDIPlayer();

  // Accessor Methods
  HINSTANCE GetInstance() { return m_hInstance; };
  HWND      GetWindow() { return m_hWindow; };
  void      SetWindow(HWND hWindow) { m_hWindow = hWindow; };
  float		GetFOV ( ) {return m_d3dfov ;};
  LPTSTR    GetTitle() { return m_szTitle; };
  WORD      GetIcon() { return m_wIcon; };
  WORD      GetSmallIcon() { return m_wSmallIcon; };
  D3DXMATRIX*		GetProj() {return &m_proj;}
  int       GetWidth() { return m_iWidth; };
  int       GetHeight() { return m_iHeight; };
  int       GetFrameDelay() { return m_iFrameDelay; };
  void      SetFrameRate(int iFrameRate) { m_iFrameDelay = 1000 /
              iFrameRate; };
  BOOL      GetSleep() { return m_bSleep; };
  void      SetSleep(BOOL bSleep) { m_bSleep = bSleep; };
  IDirect3DDevice9*		GetDevice() {return m_Device ;}
  inline	void		TextPrint(LPCSTR szString ,int x, int y ,D3DCOLOR Color) ;
};


//-------------------------------------------------------------------
//	Template function 
//-------------------------------------------------------------------
	template<class T> void Release(T t)
	{
		if( t ){t->Release();t = 0;}
	}
		
	template<class T> void Delete(T t)
	{
		if( t ){delete t;t = 0;}
	}

	inline	void		GameEngine::TextPrint(LPCSTR szString ,int x, int y ,D3DCOLOR Color) 
	{ 
		RECT rect = {x, y, m_iWidth, m_iHeight};
		m_pFont->DrawText(NULL,szString,-1,&rect,DT_TOP | DT_LEFT,Color);
	}