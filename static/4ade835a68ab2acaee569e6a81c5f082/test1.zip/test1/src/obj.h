//-----------------------------------------------------------------
// OBJ class header 
//	Dec 10			ver1.0
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
# include "mymacro.h"
# include "d3dx9.h"
# include "GameEngine.h"
# include <vector>

//these may be changed to inline
#define			MAX( x, y )    ( (x>y)? (x): (y) )
#define			MIN( x, y )    ( (x<y)? (x): (y) )
extern GameEngine*		g_pGame;

//-----------------------------------------------------------------
// OBJ Class
//-----------------------------------------------------------------
class Obj
{
protected:
	ID3DXPMesh*                      m_PMesh ;							//d3d stuff
	std::vector<D3DMATERIAL9>			m_Mtrls;
	std::vector<IDirect3DTexture9*>		m_Textures;
	struct Position
	{
		float x;
		float y;														//coordinates of the game plane (2D)
	}											m_Position ;
	D3DXMATRIX					m_WorldMatrix ;
	D3DXMATRIX					m_LocalMatrix;		//remain unchanged
	D3DXVECTOR3					m_velocity;				//the x z may not be used I just leave it vector 
	D3DXVECTOR3					m_min;						//the min and max of bounding box
	D3DXVECTOR3					m_max;
	float										m_iBulk ;						//the bulk of the obj ,used in scale transformation as factor
	int										m_iFaces;					//progressive mesh 's faces
	int										m_iDieDelay ;				// used to maintain the alpha of the obj,for better effect
	int										m_iDelayMax ;			//die's delay!!!!!!!!!
	int										m_iDelayTick;				// tickcout for alpha effect , I just came out the idea 
	bool										m_dying;						// it is hitted by enemey
	bool										m_hidden;					// when it's hidden it will reappear judged by some conditions
	int										m_iHiddenDelay ;		// reappear should wait
	int										m_iTheta ; // when ship up and down,the body will roll a angle of theta
	int										m_iThetaMax ;		// 0 means infinity
	int										m_iMaxX,m_iMaxY;	//in screen coordinates
	const float							Z ;	//the depth of obj
public:
	Obj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device );
	Obj();
	Obj::~Obj() {	Release(m_PMesh );	/*Delete(m_Textures)*/;}
	// GET & SET & ADD & REMOVE & IS 
	ID3DXPMesh*	GetPMesh () {return m_PMesh ;}
	D3DXVECTOR3 *		GetBoxMin () {return &m_min ;}
	D3DXVECTOR3 *		GetBoxMax () {return &m_max; }
	void		SetBoxMin (D3DXVECTOR3 *	v) {m_min  = *v;}
	void		SetBoxMax (D3DXVECTOR3 *	v) {m_max = *v; }
	float		GetAlpha () {return (float)m_iDieDelay /(float)m_iDelayMax;}
	int		GetTheta ( ) {return m_iTheta ;}
	Position	* GetPosition () {return  &m_Position ;}
	float		GetPositionX () {return  m_Position.x ;}
	float		GetPositionY () {return  m_Position.y;}
	float		GetZ () {return Z;}
	inline	void		SetTheta ( int n ) ;
	void		SetMaxTheta ( int n ) { m_iThetaMax = n;}
	void		SetBulk (float f ) {m_iBulk = f ;}
	float		GetBulk ( ) { return m_iBulk ;}
	void		SetDieDelay ( int n ) { m_iDieDelay = n; }
	void		SetHiddenDelay(int n ) { m_iHiddenDelay = n;}
	int		GetTimeDelay ( ) { return m_iDieDelay ;}
	void		AddFaces (int n) { m_iFaces += n ;m_PMesh->SetNumFaces(m_iFaces); }
	void		RemoveFaces (int n) {m_iFaces -= n ;m_PMesh->SetNumFaces(m_iFaces);}
	void		SetPosition ( float x , float y ) { m_Position.x = x ; m_Position.y = y;}
	inline	void		SetPosition ( int screen_x, int screen_y ) ;//
	int		SetFaces ( int n) {	m_iFaces = n ;m_PMesh->SetNumFaces(m_iFaces); }
	bool		IsDying () {return m_dying ;}
	bool		IsHidden () { return m_hidden ;}
	void		Die (bool b) {m_dying = b;}
	void		Hidden (bool b ) {m_hidden = b;}
	void		SetVelocity ( const D3DXVECTOR3 *v ) { m_velocity = *v;}
	void		SetLocalMatrix ( D3DXMATRIX * d3dxmat ) { if ( m_LocalMatrix ) m_LocalMatrix = *d3dxmat ;return;}
	inline	bool		IsOutofScreen ();
	bool			IsHitted(Obj *ptrObj);
	// UPDATE & DRAW
	inline	void		Appear( int screen_x , int screen_y ,const D3DXVECTOR3 * ptrv) ;
	void		ResetMatrix () { D3DXMatrixIdentity( &m_WorldMatrix ); 
											D3DXMatrixIdentity( &m_LocalMatrix ) ;}
	bool		ComputeBoundingBox( );
	bool		Draw ( IDirect3DDevice9*	Device ) ;
	virtual		bool		Update ( )  ;
	void		UpdateMatrix ();			//This Function Update The World Matrix
	void		ComputeScreenCord() {}
};
inline	void		Obj::SetTheta ( int n ) 
{
		// this function I can't find a better way to code now ,
		// so leave for later
		if ( n== 0 ) {	m_iTheta = n; return; }
		if ( m_iThetaMax ==  0 ) {	m_iTheta = n; return; }
		if ( n > 0 && (m_iThetaMax> n) ){	m_iTheta = n; return; } 
		else if ( n >0 ) {	m_iTheta = m_iThetaMax; return; }
		if ( n < 0 && (m_iThetaMax> -n) ){	m_iTheta = n; return; } 
		else if ( n <0 ) {	m_iTheta = -m_iThetaMax; return ;}
}

inline	void		Obj::SetPosition ( int screen_x, int screen_y ) 
{
	float zz = Z*tan(g_pGame->GetFOV()/2.0f);
	m_Position.x = (2.0f*screen_x  -   g_pGame->GetWidth())   /(g_pGame->GetWidth())*zz;
	m_Position.y = (g_pGame->GetHeight()- screen_y*2.0f)/(g_pGame->GetWidth())*zz ;
}//
//---------------------------------------------------------------------------
// Below code may not be used for now DEC 17 3pm
//---------------------------------------------------------------------------
inline	bool		Obj::IsOutofScreen ()		 // It may USELESS now DEC 17 3pm
{
	// Y?
	//float zz1 = Z*tan(g_pGame->GetFOV()/2.0f);
	//float zz2 = zz1/(g_pGame->GetWidth())*(g_pGame->GetHeight());
	//if (/*( m_Position.x > -zz1)&&( m_Position.x <zz1)*/
	//	( m_Position.y > -zz2)&&( m_Position.y <zz2))return 0;
	//else return 1;
	return 1;

}

inline	void		Obj::Appear( int screen_x , int screen_y ,const D3DXVECTOR3 * ptrv) 
{
	SetPosition( screen_x , screen_y);
	SetVelocity( ptrv) ;
	Hidden(false);
	Die(false);
	
}