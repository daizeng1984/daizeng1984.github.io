//-----------------------------------------------------------------
// EnemyObj Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "BulletObj.h"
#include "GameEngine.h" //for the Realease template 
extern GameEngine*		g_pGame;
void	Bombard(float x , float y );
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//Function Implemenation
//-----------------------------------------------------------------
bool		BulletObj::IsHitted(Obj *ptrObj) // this is target overload the function because m_min &m_max is small
{
	if ( ptrObj->IsDying() || ptrObj->IsHidden() ) return 0;
	// compute the X Y coordinates
	float x1 =  m_Position.x+m_min.x*(MAXBOUNDMULTIPLIER)-MAXTOUCHOFBULLET  ; 
	float x2 = m_Position.x + m_max.x *(MAXBOUNDMULTIPLIER) +MAXTOUCHOFBULLET;
	float y1 = m_Position.y + m_min.y*(MAXBOUNDMULTIPLIER)-MAXTOUCHOFBULLET ; 
	float y2 = m_Position.y + m_max.y *(MAXBOUNDMULTIPLIER)+MAXTOUCHOFBULLET;
	float _x1 = ptrObj->GetPositionX() +ptrObj->GetBoxMin()->x *(MAXBOUNDMULTIPLIER)- MAXTOUCHOFBULLET; 
	float _x2 = ptrObj->GetPositionX() + ptrObj->GetBoxMax()->x *(MAXBOUNDMULTIPLIER)+MAXTOUCHOFBULLET;
	float _y1 = ptrObj->GetPositionY() +ptrObj->GetBoxMin()->y*(MAXBOUNDMULTIPLIER) -MAXTOUCHOFBULLET; 
	float _y2 = ptrObj->GetPositionY() + ptrObj->GetBoxMax()->y *(MAXBOUNDMULTIPLIER)+MAXTOUCHOFBULLET;
	// Check if they collides?
	if ( ( MAX(x1,x2 ) >MIN(_x1,_x2 ))
			&&( MAX(_x1,_x2 ) >MIN(x1,x2 ))
			&&( MAX( y1, y2) >MIN( _y1, _y2))
			&&( MAX( _y1, _y2) >MIN(y1, y2 )))
	return true;
	else return false;
	return 0;
}
// this function has been USELESS so I RELOAD ONE JUST PASS IT! DEC 17 3pm
bool		BulletObj::Update()
{
	float zz  = GetZ()*tan(g_pGame->GetFOV()/2.0f);
		if ( (!m_hidden ) )
	{
		// Out of Screen?
		if (m_Position.x  < -zz - BULLETSCREEN_OFFSET	
			||  m_Position.x  > zz +BULLETSCREEN_OFFSET)				//another 'magic' number , offset when enemy exceed screen( CHANGED to MACRO)DEC 17 3pm 
		{

			m_hidden = true;
			return 1;

		}
		else 
		{
			//check all the ship ,see if it hit someone
		}

		UpdateMatrix();


		return 1;
	}
	else if ( m_dying ) 
	{
		
		//m_iDieDelay -= m_iDelayTick;
		////check if m_iDieDelay is minus!!
		//if ( m_iDieDelay < 0 ) {
		//	m_iDieDelay = m_iDelayMax;
		//	m_dying = false ;
		//	m_hidden = true;
		//	m_iHiddenDelay = m_iHiddenMax ;
		//}
		return 1;
	}
	else if ( m_hidden )		// it's a littel strange to name this var hidden( I don't know 
	{
		//	//do nothing when hidden
		//}
		//else
		//{
		//	//wait do nothing 

		//}
		return 1;
	}
	return 1;
}
// this is the RELOADED UPDATE
bool		BulletObj::Update( ShipObj  * player , EnemyObj* enemy[] ,BulletObj * bullet[] )
{
		float zz  = GetZ()*tan(g_pGame->GetFOV()/2.0f);
		if ( (!m_hidden ) )
	{
		//Out of Screen?
		// don't worry about 640.0f  I tune offset in 640*480 so I keep it, the offset will be scale when
		// screen changes,JUST PASS IT
		if (m_Position.x -MAXTOUCHOFBULLET
			< -zz - BULLETSCREEN_OFFSET/640.0f*g_pGame->GetWidth()
			||  m_Position.x +MAXTOUCHOFBULLET
			> zz +BULLETSCREEN_OFFSET/640.0f*g_pGame->GetWidth()
			)
		{

			m_hidden = true;
			// decrease the bullet count for player and enemy
			if ( m_iWhoFire == FIRE_BY_PLAYER )
				player->DecrBullet() ;
			else  
				enemy[m_iWhoFire] ->DecrBullet();
			return 1;

		}
		else 
		{
			// Hit Players?
			if ( IsHitted(player) && m_iWhoFire != FIRE_BY_PLAYER 
				&& !player->IsDying() && !player->IsHidden())
			{
				m_hidden = true;//bullet disappear
				enemy[m_iWhoFire]->DecrBullet() ;
				player->KillLife();
				player->Die(true);
				::PlaySound(_T("..\\..\\data\\BLAST1.WAV"),NULL,SND_ASYNC  | SND_NOWAIT);
				//BOMB!
				Bombard(player->GetPositionX(),player->GetPositionY());
				return 1;
			}
			//Hit Enemys?
			for ( int i = 0 ; i < MAXENEMY ; ++ i )
			{
				if ( m_iWhoFire == FIRE_BY_PLAYER && IsHitted(enemy[i]) )
					//enemy can NOT shoot enemy
				{
					m_hidden = true;//bullet disappear
					
					enemy[i]->Die(true);
					enemy[i]->DecrEnemy();
					//BOMB!
					Bombard(enemy[i]->GetPositionX(),enemy[i]->GetPositionY());

					if (m_iWhoFire == FIRE_BY_PLAYER )
					{
						player->GainScore();
						player->DecrBullet() ;
					}
					else
						enemy[m_iWhoFire] ->DecrBullet();
					return 1;
				}
			}
			//check all the ship ,see if it hit someone(I assigns Players Ship to check this)
		}

		UpdateMatrix();


		return 1;
	}
	else if ( m_dying ) 
	{
		// do nothing
		return 1;
	}
	else if ( m_hidden )	
	{
		// do nothing ,wait to be relife
		return 1;
	}
	return 1;
}