//-------------------------------------------------------------------
//  ALL MACRO STUFF
//	it may not be good to join them together but for this demo
// it may be convinent to tune them this way.
//-------------------------------------------------------------------
// +   + means the bigger the more ... -   -  meaning is similar
/*#define		_VC_6_0_			*/			//for VC6.0 Undefine for VC2005

#pragma warning(disable:4819) //to eliminate the warning of deprecated

#ifdef		_VC_6_0_

#define		LoopInt
#define			MAX( x, y )    ( (x>y)? (x): (y) )
#define			MIN( x, y )    ( (x<y)? (x): (y) )

#else
typedef		int		LoopInt;
#endif

//-------------------------------------------------------------------
#define		MAXBKDROPCHANGE 200				//useless

#define		CHANGESTEPINITIAL  0.0005f			// + +  BKG's Moving speed

#define		MAXTOUCHOFBULLET	1.0F		//+   + bullet 's bounding tune only for bullet
#define		FIRE_BY_PLAYER  -1					//ENUM bullet's attribute,is it fire from player or enemy 12(ID)?

#define		MAXENEMY				30			//if this change the global below should be changed 
#define		MAXENEMYBULLET  1				//per enemy's max bullet
#define		MAXENEMYVEL		0.5f					// +  +
//#define		MAXENEMYFIREDELAY   10
#define		FIRECHANCE			100					//not 100%! 100 is a number ,not probablity,+ +

#define		MAXBOUNDMULTIPLIER	0.05f			// i don't know why mesh's bound computation is ridiculus
#define		SCREEN_OFFSET		150.0f							//+   +tune the  enemy's screen offset
#define		BULLETSCREEN_OFFSET		40.0f			// +   +  tune the bullet 
#define		MAXDIEDELAY		256					//+   +
#define		DIEDELAYTICK			5					//+   +
#define		MAXHIDDENDELAY	100						//+   +for enemy reappear
#define		MAXTHETA				30						//+   +
#define		OBJZDEPTH				150.0f						//+   +

#define		MAXLIFE			3									// player's life
#define		MAXBULLET		10								//player's maxbullet
//#define		MAXINVETDELAY			100


#define		GLOBALMAXBULLET     100			//+ +	 there are only limit number of bullet
#define		GLOBALFIREDELAY	3		//+ +firedelay of player
//#define		PLAYERDELAYAFTERRELIFE			10		// + + delay when relife
#define		GLOBALMAXENEMY  30		//+ +enemy list total
#define		WINNINGSCORE			1000		// + +wining score
#define		GLOBALDEFAULTBULLETSPEED      4.0f // default bullet speed
#define		ENEMYBULLETSPEED					1.5f
#define		GLOBALFOV						D3DX_PI/4.0f		//FOVof the game
#define		Z_GLOBALBKG				900.0f		//background zdepth
#define		BACKGROUNDTUNE			3.0f				//+ + if the background is ...
#define		SCREENWIDTH					1024
#define		SCREENHEIGHT				768
#define		GLOBALOBJBULK					0.6f			//all the Ship and enemy is this bulk
#define		GLOBALBULLETBULK			5.0f			// bulk for bullet
#define		PLAYERBOXTUNE				2.3F				// player's box should be small cause we are player
#define		PLAYERMOVINGSPEED			1.0f																				//DEC 17 added after reread the requirement
#define		TOTALMAXENEMYBULLET			10			//+ +
#define		GLOBALBOMBARD								10
#define		ANIMATION_MAXFRAMEDELAY		3		// + +
#define		ANIMATIONWIDTH								4
#define		ANIMATIONHEIGHT							3
#define		ANIMATIONMAXFRAMENUM				11	//12 frame
#define		SPIRITSPAN											17.0f