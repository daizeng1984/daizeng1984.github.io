//-----------------------------------------------------------------
// BULLETOBJ class header 
//	Dec 10			ver1.0
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
# include "mymacro.h"
# include "d3d9.h"
# include "Obj.h"
# include "EnemyObj.h"
# include "ShipObj.h"
# include <vector>
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// BulletObj Class
//-----------------------------------------------------------------
class BulletObj : public Obj
{
	int		m_iWhoFire;			// - 1 represent players
public:
	/*BulletObj::BulletObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device  );*/
	BulletObj::BulletObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device ) 
		: Obj(szXFilename ,Device ) {}
	virtual bool		Update();
	virtual	bool		Update( ShipObj  * player , EnemyObj* enemy[] ,BulletObj * bullet[] =0 );
	/*virtual bool Update( const vector<Obj*> &ptrObjlist ) ;*/
	// GET & SET & IS
	void		SetHitEnemy ( int whofire) { m_iWhoFire = whofire;}
	bool		IsFriendBullet() { if (m_iWhoFire == FIRE_BY_PLAYER ) return true ;return false;}
	bool		IsHitted(Obj * ptrObj);
};
