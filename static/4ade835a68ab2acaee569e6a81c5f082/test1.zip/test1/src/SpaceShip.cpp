//-----------------------------------------------------------------
// SpaceShip.cpp				ver 1.0
// by Dave Dseng				DEC.9 07
//	Main Structure of the game , the whole frameworks is from 
//	McMorrison <Beginning  Game Programming>
//	
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "SpaceShip.h"
/////////////////////////////////////////////////////////////////////
const float PI = 3.14159f;
const float PlayerMovingSpeed = PLAYERMOVINGSPEED ;
#define KEY_DOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEY_UP(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

//-----------------------------------------------------------------
// Game Engine Functions
//-----------------------------------------------------------------
BOOL GameInitialize(HINSTANCE hInstance)
{
  // Create the game engine
  g_pGame = new GameEngine(hInstance, TEXT("UBITEST"),
    TEXT("SpaceShip"), TRUE , SCREENWIDTH,SCREENHEIGHT ,D3DDEVTYPE_HAL ,D3DX_PI/4.0f );
  if (g_pGame == NULL)
    return FALSE;

  // Set the frame rate
  g_pGame->SetFrameRate(100);
  
  // Store the instance handle
  g_hInstance = hInstance;

  return TRUE;
}

void GameStart(IDirect3DDevice9*		Device)
{
	// no cursor
	ShowCursor(false);
	srand(GetTickCount());
	Device = (g_pGame->GetDevice());
	//load mesh and some Obj
	//BACKGROUD
	g_pBackDrop = new BackDrop( _T("..\\..\\data\\ResBG3.png") , Device,
		BACKGROUNDTUNE*Z_GLOBALBKG*(::tan(GLOBALFOV/2.0f)),BACKGROUNDTUNE*(float)g_pGame->GetHeight()*Z_GLOBALBKG*(::tan(GLOBALFOV/2.0f))/((float)g_pGame->GetWidth()),Z_GLOBALBKG);
	//MESH
	g_pShipObj = new ShipObj(_T("..\\..\\data\\bigship1.x"), Device );
	g_pEnemyObj = new EnemyObj(_T("..\\..\\data\\bigship1.x"), Device );
	g_pBulletObj =  new BulletObj(_T("..\\..\\data\\arrow.x"), Device );
	g_pAnimator =  new Animation(_T("..\\..\\data\\ResBlast1.bmp"),Device,SPIRITSPAN,SPIRITSPAN,OBJZDEPTH,
		ANIMATIONWIDTH,ANIMATIONHEIGHT,ANIMATIONMAXFRAMENUM);
	//start player
	StartPlayer(g_pShipObj);
	//and reset the score and life
	g_pShipObj->SetScore(0);
	g_pShipObj->SetLife(MAXLIFE);
	// THE ENEMY& BULLET BELOW IS JUST MEMCOPY OBJ OF THE PROTOTYPE
	// g_pEnemyObj g_pBulletObj AND DIDN'T READ MESH JUST USE THE SAME
	// MESH ! DEC 17 3pm SO YOU LL SEE WHEN INITIAL AND DELETE THERE'S DIFFERENCE
	//start enemy
	for ( int i = 0 ; i < GLOBALMAXENEMY ; i ++ )
	{
		g_pEnemyObjList [i] =  StartEnemy();//1.2f,100,1,g_pGame->GetWidth() + SCREEN_OFFSET,g_pGame->GetHeight()) ;
			/*g_pEnemyObjList [i ]->IncrEnemy();*/
			/*if (!( g_pEnemyObjList[i] ->CanReappear() ))*/
			g_pEnemyObjList [i ]->Hidden(true);
	}
	
	//start bullet 
	for ( LoopInt  i= 0 ; i < GLOBALMAXBULLET ; ++ i )
	{
		g_pBulletObjList[i] = new BulletObj(*g_pBulletObj);
		g_pBulletObjList[i]->Die(false);
		g_pBulletObjList[i]->Hidden(true);

	}

	//start Bombard
	for ( LoopInt  i= 0 ; i < GLOBALBOMBARD ; ++ i )
	{
		g_pBombardList[i] = new Animation(*g_pAnimator);
		//g_pBombardList[i]->Die(false);
		//g_pBombardList[i]->Hidden(true);

	}
	/*	g_pBulletObjList [i] =  0;*/

	//Initial light and some stuff for d3d9
	InitialD3D (Device);
	
}

void GameEnd()
{
	// delete all the bullet
	for ( int  i= 0 ; i < GLOBALMAXBULLET ; ++ i )
	{
		delete g_pBulletObjList[i] ;

	}
	// delete all the enemy
	for ( LoopInt i = 0 ; i < GLOBALMAXENEMY ; i ++ )
	{
		delete g_pEnemyObjList [i];
	}
	for ( LoopInt  i= 0 ; i < GLOBALBOMBARD ; ++ i )
	{
		delete g_pBombardList[i] ;

	}
	delete (BackDrop*)g_pAnimator;
	delete g_pBackDrop;
	delete g_pShipObj ;
	//delete prototype of obj
	delete (Obj *)g_pEnemyObj;
	delete (Obj *)g_pBulletObj;
  // Cleanup the game engine
  delete g_pGame;

}


void GameCycle()
{
		IDirect3DDevice9*		Device = (g_pGame->GetDevice());
//---------------------------------------------------------------
//		Update the Obj
//-----------------------------------------------------------------
		//update background
		//i choose to update while draw ,cause it's simple
		//update players
		g_pShipObj->Update(g_pEnemyObjList);
		//update enemy
		for ( int i = 0 ; i < MAXENEMY ; ++i )
		{
			if (g_pEnemyObjList[i])g_pEnemyObjList[i]->Update(i);
		}
		//update bullet
		for ( LoopInt i = 0 ; i < GLOBALMAXBULLET ; ++i )
		{
			if (g_pBulletObjList[i])g_pBulletObjList[i]->Update(g_pShipObj , g_pEnemyObjList);
		}
		for ( LoopInt  i= 0 ; i < GLOBALBOMBARD ; ++ i )
		{
			if (g_pBombardList[i])g_pBombardList[i]->Update();
			/*g_pBombardList[i] = new Animation(*g_pAnimator);*/
		}
//---------------------------------------------------------------------
//	Draw the buffer
//---------------------------------------------------------------------
		//d3d
		Device->Clear(0, 0, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0);
		Device->BeginScene();
		//this logic is used to shake the camera
		if ( g_pShipObj->IsDying())
		{
		D3DXVECTOR3 position( 0.0f, 0.0f, -1.0f );
		D3DXVECTOR3 target((rand()%100)/10000.0f , (rand()%100)/10000.0f, (rand()%100)/10000.0f);
		D3DXVECTOR3 up(0.0f, 1.0f, 0.0f);
		D3DXMATRIX V;
		D3DXMatrixLookAtLH(&V, &position, &target, &up);

		Device->SetTransform(D3DTS_VIEW, &V);
		}
		//Draw BackDrop
		g_pBackDrop ->Draw(Device);	
		//Draw Bombard!!!
		for ( LoopInt  i= 0 ; i < GLOBALBOMBARD ; ++ i )
		{
			if (g_pBombardList[i])g_pBombardList[i]->Draw(Device);
			/*g_pBombardList[i] = new Animation(*g_pAnimator);*/
		}
		//Draw player
		//change color
		// I SET LIGHT WHEN DRAW WHICH MAKES
		// DIFFERENT COLOR! I HAVE ONLY 2MESHES!
		// OF COURSE CHANGE THE MATERIAL MAY BE
		// A GOOD WAY      DEC 17 3pm
		//************************************************
		D3DLIGHT9 light;
		::ZeroMemory(&light, sizeof(light));
		light.Type      = D3DLIGHT_DIRECTIONAL;
		light.Ambient   = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
		light.Diffuse   = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
		light.Specular  = D3DXCOLOR(0.9f, 0.9f, 0.9f, 1.0f);
		light.Direction = D3DXVECTOR3(1.0f, -1.0f, 0.5f);
		Device->SetLight(0, &light);
		Device->LightEnable(0, true);		
		//************************************************
		g_pShipObj->Draw(Device );

		//draw enemy
		//************************************************
		light.Type      = D3DLIGHT_DIRECTIONAL;
		light.Ambient   = D3DXCOLOR(0.0f, 0.0f, 0.9f, 1.0f);
		light.Diffuse   = D3DXCOLOR(0.0f, 0.0f, 1.0f, 1.0f);
		light.Specular  = D3DXCOLOR(0.0f, 0.0f, 0.0f, 1.0f);
		light.Direction = D3DXVECTOR3(1.0f, -1.0f, 0.5f);
		Device->SetLight(0, &light);
		//************************************************
		for ( LoopInt i = 0 ; i < MAXENEMY ; ++i )
		{
			if (g_pEnemyObjList[i])g_pEnemyObjList[i]->Draw(Device );
		}
		//draw bullet
		//************************************************
		light.Type      = D3DLIGHT_DIRECTIONAL;
		light.Ambient   = D3DXCOLOR(0.0f, 1.0f, 0.0f, 1.0f);
		light.Diffuse   = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
		light.Specular  = D3DXCOLOR(0.0f, 0.0f, 0.0f, 0.0f);
		light.Direction = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		Device->SetLight(0, &light);
		//************************************************
		for ( LoopInt i = 0 ; i < GLOBALMAXBULLET ; ++i )
		{
			if (g_pBulletObjList[i] && !g_pBulletObjList[i]->IsFriendBullet()) g_pBulletObjList[i]->Draw(Device );
			else
			{
				light.Ambient   = D3DXCOLOR(1.0f, 0.0f, 0.0f, 1.0f);
				Device->SetLight(0, &light);
				g_pBulletObjList[i]->Draw(Device );
				//set back to above
				light.Ambient   = D3DXCOLOR(0.0f, 1.0f, 0.0f, 1.0f);
				Device->SetLight(0, &light);
			}
		}
		//Draw text
		TCHAR p[30];//temp
		wsprintf (p,_T("SCORE:%5d"), g_pShipObj->GetScore() );
		g_pGame->TextPrint(p,20,20,D3DCOLOR_ARGB(255, 255, 255, 0));
		wsprintf (p, _T("LIFE:%3d"), g_pShipObj->GetLife() );
		g_pGame->TextPrint(p,400,20,D3DCOLOR_ARGB(255, 255, 255, 0));
		if ( g_pShipObj->GetLife() <= 0 ) 
		{
			g_pGame->TextPrint(_T(" Game Over! Esc to Exit!"),
				int(g_pGame->GetWidth()/4.0f) ,int(g_pGame->GetHeight()/2.4f) ,
				D3DCOLOR_ARGB(255, 255, 0, 0));
		}
		else
		if ( g_pShipObj->GetScore() >= WINNINGSCORE )//magic number ?
		{
				g_pGame->TextPrint(_T(" You Win! Esc to Exit!"),
				int(g_pGame->GetWidth()/4.0f) ,int(g_pGame->GetHeight()/2.4f) ,
				D3DCOLOR_ARGB(255, 0, 255, 0));
				g_pShipObj->Hidden(true);
		}
		else if ( g_pShipObj->IsHidden() )
		{
				g_pGame->TextPrint(_T("SPACE TO CONTINUE!"),
				int(g_pGame->GetWidth()/4.0f) ,int(g_pGame->GetHeight()/2.4f) ,
				D3DCOLOR_ARGB(255, 255, 0, 0));
		}
		//end of Draw
		Device->EndScene();
		Device->Present(0, 0, 0, 0);
}

void HandleKeys()
{
	D3DXVECTOR3  vector(0.0f,0.0f,0.0f);
	//up or down velocity?
	// zz1 : x : width of the scene
	// zz2 : y : height of the scene
	float zz1 = g_pShipObj->GetZ()*tan(g_pGame->GetFOV()/2.0f);
	float zz2 = zz1/(g_pGame->GetWidth())*(g_pGame->GetHeight());
	static bool	IsSpaceDown = false;
	 if ( KEY_DOWN(VK_UP) )
	 {
		 // no out of scene
		 if ( ((g_pShipObj->GetPosition())->y) < zz2) {
			 vector.y = PlayerMovingSpeed;
			 g_pShipObj->SetVelocity(&vector );
			 g_pShipObj->SetTheta(g_pShipObj->GetTheta()+3);
		 }
		 else
		 {
			vector.y = 0.0f;
			g_pShipObj->SetVelocity(&vector );
			g_pShipObj->SetTheta(g_pShipObj->GetTheta()+3);
		 }
		 
	 }
	 else
	 if ( KEY_DOWN(VK_DOWN))
	 {
		 // no out of scene
		 if ( ((g_pShipObj->GetPosition())->y) > -zz2) {
			 vector.y = -PlayerMovingSpeed;
			 g_pShipObj->SetVelocity(&vector );
			 g_pShipObj->SetTheta(g_pShipObj->GetTheta()-3);
		 }else
		 {
			 vector.y = 0.0f;
			 g_pShipObj->SetVelocity(&vector );
			 g_pShipObj->SetTheta(g_pShipObj->GetTheta()-3);
			}
	 }
	 else
	 {
		vector.y = 0.0f;
		 g_pShipObj->SetVelocity(&vector );
	 }
	if ( KEY_DOWN(VK_SPACE) )
	{
		if ( !IsSpaceDown )
		{
		//space down
		IsSpaceDown = true;
		//player dead:
		if ( g_pShipObj->IsDying() )return ;
		if (g_pShipObj->IsHidden()  && (g_pShipObj->GetLife()>0) && g_pShipObj->GetScore() <WINNINGSCORE)
		{
			StartPlayer(g_pShipObj);
			//g_pFireDelay = PLAYERDELAYAFTERRELIFE;
			return;
		}
		}
		//not dead:
		if ( g_pShipObj->CanFire() && (!g_pShipObj->IsHidden()) )//&& g_pShipObj->GetScore() <250 )  

		{
			//fire! please delay it!
			if (-- g_pFireDelay  < 0 )
			{
				float x = g_pShipObj->GetPositionX();
				float y =  g_pShipObj->GetPositionY();
				////////////////////////////////////////
				Fire(FIRE_BY_PLAYER,x,y);
				g_pShipObj->IncrBullet();
				//who can do the decrease stuff?      bullet stuff
				// LEAVE IT TO BULLET IS QUIT GOOD TRUST ME!
				// YOU WANT MESS UP THE STRUCTURE
				g_pFireDelay = GLOBALFIREDELAY;
			}
		}
	}
	if ( KEY_UP(VK_SPACE) )
		IsSpaceDown = false;
	
}

void MouseButtonDown(int x, int y, BOOL bLeft)
{
}

void MouseButtonUp(int x, int y, BOOL bLeft)
{
}

void MouseMove(int x, int y)
{
}

//-----------------------------------------------------------------
// Functions
//-----------------------------------------------------------------

void	StartPlayer(ShipObj*	pShipObj , float bulk   , int diedelay  , int maxtht ,int x,int y  )
{
	//initial a player:
	pShipObj->ResetMatrix();
	pShipObj->Die(false);
	pShipObj->Hidden(false);
	pShipObj->SetBulk(bulk);
	pShipObj->SetDieDelay(diedelay);
	pShipObj->SetTheta(0);
	pShipObj->SetMaxTheta(maxtht);
	pShipObj->SetPosition(x, y);
	//pShipObj->SetScore(0);
	D3DXVECTOR3 v(*pShipObj->GetBoxMin()) , u (*pShipObj->GetBoxMax()) ;
	v /= PLAYERBOXTUNE; u /= PLAYERBOXTUNE;
	//tune players min max box
	pShipObj->SetBoxMin( &v ) ;pShipObj->SetBoxMax( &u ) ;

	D3DXMATRIX		Mat;
	D3DXMatrixRotationY( &Mat , -D3DX_PI/2.0f);
	pShipObj->SetLocalMatrix(&Mat);
}
EnemyObj* StartEnemy( float bulk , int diedelay  , int maxtht ,int x,int y ,float vel )
{
	// initial enemy create copy of prototype
	EnemyObj * pEnemyObj = new EnemyObj(*g_pEnemyObj);
	pEnemyObj->ResetMatrix();
	pEnemyObj->Die(false);
	pEnemyObj->Hidden(false);
	pEnemyObj->SetBulk(bulk);
	pEnemyObj->SetDieDelay(diedelay );
	pEnemyObj->SetHiddenDelay(MAXHIDDENDELAY + rand()%MAXHIDDENDELAY );
	pEnemyObj->SetTheta(0);
	pEnemyObj->SetMaxTheta(maxtht);
	pEnemyObj->SetPosition(x, y);
	D3DXMATRIX		Mat;
	D3DXMatrixRotationY( &Mat ,D3DX_PI/2.0f);
	pEnemyObj->SetLocalMatrix(&Mat);
	D3DXVECTOR3 v(vel, 0.0f,0.0f );
	pEnemyObj->SetVelocity(&v);
	return pEnemyObj;
}
void Fire(int whofire,float x,float y , float bulk   , int diedelay  , int maxtht ,float vel )
{
	// this function will "new" a new bullet
	// GIVEN A MAX BULLET NUM IN COMPILE TIME , THE NEW IS JUST RELIFE
	// AND INITIAL A BULLET DEC 17 4pm
	//direction of bullet
			int	dir;
			if ( whofire == FIRE_BY_PLAYER )  dir = 1;
			else dir = -1;
	//can we fire? enough space to add new bullet ?
		for ( int i = 0 ; i < GLOBALMAXBULLET ; ++ i ) 
	{
		if ( !g_pBulletObjList[i] ) //we need new bullet obj to llocate mem
		{
			g_pBulletObjList[i] = new BulletObj(*g_pBulletObj);
			
			g_pBulletObjList[i]->ResetMatrix();
			g_pBulletObjList[i]->Die(false);
			g_pBulletObjList[i]->Hidden(false);
			g_pBulletObjList[i]->SetBulk(bulk);						//?
			g_pBulletObjList[i]->SetDieDelay(diedelay);			// = 0
			g_pBulletObjList[i]->SetTheta(0);
			g_pBulletObjList[i]->SetMaxTheta(maxtht);			
			g_pBulletObjList[i]->SetPosition(x, y);
			g_pBulletObjList[i]->SetHitEnemy(whofire);
			D3DXMATRIX		Mat;
			D3DXMatrixRotationY( &Mat , -(dir)*D3DX_PI/2.0f);
			g_pBulletObjList[i]->SetLocalMatrix(&Mat);
			D3DXVECTOR3 v(dir*vel, 0.0f,0.0f );		//positive!
			g_pBulletObjList[i]->SetVelocity(&v);
			::PlaySound(_T("..\\..\\data\\Fire.WAV"),NULL,SND_ASYNC | SND_NOSTOP );
			return;
		}
		else if ( g_pBulletObjList[i]->IsHidden () )
		{
			g_pBulletObjList[i]->ResetMatrix();
			g_pBulletObjList[i]->Die(false);
			g_pBulletObjList[i]->Hidden(false);
			g_pBulletObjList[i]->SetBulk(bulk);						//?
			g_pBulletObjList[i]->SetDieDelay(diedelay);			// = 0
			g_pBulletObjList[i]->SetTheta(0);
			g_pBulletObjList[i]->SetMaxTheta(maxtht);			
			g_pBulletObjList[i]->SetPosition(x, y);
			g_pBulletObjList[i]->SetHitEnemy(whofire);
			D3DXMATRIX		Mat;
			D3DXMatrixRotationY( &Mat , -(dir)*D3DX_PI/2.0f);
			g_pBulletObjList[i]->SetLocalMatrix(&Mat);
			D3DXVECTOR3 v(dir*vel, 0.0f,0.0f );		//positive!
			g_pBulletObjList[i]->SetVelocity(&v);
			::PlaySound(_T("..\\..\\data\\Fire.WAV"),NULL,SND_ASYNC|SND_NOSTOP );
			return;
		}
		}
		return ; //can't fire now...........
}
//void StartBullet( float bulk   , int diedelay  , int maxtht ,int x,int y ,float vel )
void	InitialD3D(IDirect3DDevice9*	Device )
{
	// d3d stuff copy from FRANK LUNA's books example
	D3DLIGHT9 light;
	::ZeroMemory(&light, sizeof(light));
	light.Type      = D3DLIGHT_DIRECTIONAL;
	light.Ambient   = D3DXCOLOR(0.9f, 0.9f, 0.9f, 1.0f);
	light.Diffuse   = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	light.Specular  = D3DXCOLOR(0.9f, 0.9f, 0.9f, 1.0f);
	light.Direction = D3DXVECTOR3(1.0f, -1.0f, 0.5f);
	Device->SetLight(0, &light);
	Device->LightEnable(0, true);
		D3DXVECTOR3 position(0.0f, 0.0f, 0.0f);
		D3DXVECTOR3 target(0.0f, 0.0f, 1.0f);
		D3DXVECTOR3 up(0.0f, 1.0f, 0.0f);
		D3DXMATRIX V;
		D3DXMatrixLookAtLH(&V, &position, &target, &up);
		Device->SetTransform(D3DTS_WORLD, &V);
	Device->SetRenderState(D3DRS_NORMALIZENORMALS, true);
	Device->SetRenderState(D3DRS_SPECULARENABLE, true);
		Device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	Device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	Device->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
}