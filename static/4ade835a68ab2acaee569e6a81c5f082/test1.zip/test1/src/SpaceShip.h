//-----------------------------------------------------------------
// SpaceShip.h 
//	header for SpaceShip.cpp
//	My proj		dave dseng
//-----------------------------------------------------------------

#pragma once

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "mymacro.h"
#include <windows.h>
//#include "Resource.h"
#include "GameEngine.h"
#include "ShipObj.h"
#include "Obj.h"
#include "EnemyObj.h"
#include "BulletObj.h"
#include "BackDrop.h"
#include "BulletObj.h"
#include "Animation.h"
#include "math.h"
#include <vector>
//enum	GStates
//{
//	gamestart,
//	gameover,
//	gamestop
//}	GameStates;
//-----------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------
HINSTANCE         g_hInstance;
GameEngine*       g_pGame;
EnemyObj*			g_pEnemyObjList[GLOBALMAXENEMY];
BulletObj*			g_pBulletObjList [GLOBALMAXBULLET] = { 0 };
Animation*			g_pBombardList[GLOBALBOMBARD] = {0};
BackDrop*			g_pBackDrop;
Obj*						g_pObj;
ShipObj*				g_pShipObj;
EnemyObj*			g_pEnemyObj;
BulletObj*			g_pBulletObj;
Animation*			g_pAnimator;
int					g_pFireDelay =0 ; //delay fire 
//-----------------------------------------------------------------
// Function Declarations
//-----------------------------------------------------------------
void NewGame();
void	StartPlayer(ShipObj*	pShipObj , float bulk  = GLOBALOBJBULK , int diedelay = 100 , int maxtht  = 30,int x = 0,int y = 240  );
EnemyObj* StartEnemy( float bulk  = GLOBALOBJBULK , int diedelay = MAXDIEDELAY , int maxtht  = 1,int x = 640,int y = 480 ,float vel = -1.0f );
void Fire(int whofire ,float x,float y , float bulk =GLOBALBULLETBULK , int diedelay = 0 , int maxtht = 1,float vel = GLOBALDEFAULTBULLETSPEED );
void	InitialD3D(IDirect3DDevice9*	Device ); 
void	Bombard(float x , float y )
{
	for ( int i = 0 ; i < GLOBALBOMBARD ; ++ i )
	{
		if ( g_pBombardList[i]->IsHidden() )
		{
			::PlaySound(_T("..\\..\\data\\BLAST1.WAV"),NULL,SND_ASYNC | SND_NOWAIT);
			g_pBombardList[i]->SetPostion(x,y);
			g_pBombardList[i]->InitializeFrame() ;
			return ;
		}
	}
}