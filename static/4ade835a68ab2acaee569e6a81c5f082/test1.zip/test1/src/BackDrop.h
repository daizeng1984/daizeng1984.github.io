//-----------------------------------------------------------------
// BackDrop class header 
//	Dec 10			ver1.0
//  for SomeCode I directly copy from FrankLuna 's DX9 books
//-----------------------------------------------------------------

#pragma once
//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "mymacro.h"
# include "d3dx9.h"
//-----------------------------------------------------------------
// BackDrop Class
//-----------------------------------------------------------------

class BackDrop
{
			struct Vertex
			{
			Vertex(){}
			Vertex(
				float x, float y, float z,
				float u, float v)
			{
				_x  = x;  _y  = y;  _z  = z;
				_u  = u;  _v  = v;
			}
			float _x, _y, _z;
			float _u, _v;							// texture coordinates	just copy from Frank Luna's DX books

			static const DWORD FVF;
			};
			float			m_fWidth ;
			float			m_fHeight;	
			float			m_fDepth ;			// width height and depth of the BackDrop
			float			m_u;
			float			m_v;						//the u,v to update
			int			m_ChangeDelay;
			float			m_step;				//step every time u v change
			D3DXVECTOR3							m_Position;			//THE Z ENTRY IS USELESS
			IDirect3DVertexBuffer9*			m_BackDrop;		//Vbuffer
			IDirect3DTexture9*						m_Tex ;		//texture
public:
			/*BackDrop () {}*/
			BackDrop (	LPTSTR szFilename , IDirect3DDevice9*	Device ,
								float fWidth , float fHeight ,float fDepth );
			~BackDrop();
			void		Draw ( IDirect3DDevice9*	Device );		// i don't use update cause this method update himself
			void		Draw ( IDirect3DDevice9*	Device ,D3DXMATRIX		matTexture);
				//this ones is more directly and it's convinient for antiomation class
			// GET & SET
			DWORD	GetFVF() {return Vertex::FVF ;}
			int	GetSizeofVertex () {return sizeof(Vertex);}
			void		SetPostion ( float x , float y ) { m_Position.x = x ;m_Position.y = y;}
			//void		SetDelay
			void		SetUV( float u,float v) { m_u = u; m_v = v;}
			float		GetU () {return m_u;}
			float		GetV ()  {return m_v ; }

};

