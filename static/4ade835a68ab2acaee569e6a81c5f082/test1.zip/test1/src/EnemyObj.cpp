//-----------------------------------------------------------------
// EnemyObj Class Source
//-----------------------------------------------------------------

//-----------------------------------------------------------------
// Include Files
//-----------------------------------------------------------------
#include "EnemyObj.h"
#include "GameEngine.h" //for the Realease template 
extern void Fire(int whofire ,float x,float y , float bulk =GLOBALBULLETBULK , int diedelay = 0 , int maxtht = 1,float vel = GLOBALDEFAULTBULLETSPEED );
extern GameEngine*		g_pGame;
//-----------------------------------------------------------------
// Const and Macros
//-----------------------------------------------------------------
int	EnemyObj::iTotalEnemy = 0;
int	EnemyObj::iTotalBullet = 0;
//-----------------------------------------------------------------
//Function Implemenation
//-----------------------------------------------------------------
EnemyObj::EnemyObj(  LPTSTR szXFilename  , IDirect3DDevice9*	Device, int iHidden ) 
								: Obj(szXFilename ,Device ) , m_iHiddenMax(iHidden) ,m_iTotalBullet(0)
{}
//EnemyObj::EnemyObj( EnemyObj& enemy )
//{
//	if ( this == &enemy ) return ;
//
//}
// needn't to use copy constructor because i Didn't ACTUALLY ADD SOME WIERD POINTER STUFF!
// THE ENEMY USE THE SAME ONE MESH!just use the mem to mem copy is right!
bool		EnemyObj::Update( int enemyid)
{
	float zz  = GetZ()*tan(g_pGame->GetFOV()/2.0f);
	if ( (!m_dying ) && (!m_hidden ) )
	{
		//another 'magic' number , offset when enemy exceed screen 
		// Out of Screen?????
		if (m_Position.x  < -zz - SCREEN_OFFSET/640*g_pGame->GetWidth()	 ){
			m_dying = false ;
			m_hidden = true;
			-- iTotalEnemy  ;
			m_iHiddenDelay = m_iHiddenMax ;
			return 1;

		}
		/*else if ( 1)*///collide with player// all die-----it should let player to check

		UpdateMatrix();
		//enemy ship neednot balance
		//instead it produce bullet randomly
		//JUST PASS the 99999 , I forget the rand_max,of course you can change to rand_max 
		//but u ll need to retune the chance DEC 17 3pm
		if ( (rand()%99999 <FIRECHANCE ) 
			&& (EnemyObj::CanFire())
			&&(m_Position.x  > -zz))
		{
			Fire ( enemyid , m_Position.x , m_Position.y ,GLOBALBULLETBULK ,0,1,ENEMYBULLETSPEED) ; //fire!
			IncrBullet();
		}
		else
			//do nothing but push ahead
			;

		return 1;
	}
	else if ( m_dying ) 
	{
		//die delay is use to perform the semi-transparency of the body
		m_iDieDelay -= m_iDelayTick;
		//check if m_iDieDelay is minus!!
		if ( m_iDieDelay < 0 ) {
			m_iDieDelay = m_iDelayMax;
			//start to hidden
			m_dying = false ;
			m_hidden = true;
			-- iTotalEnemy  ;
			m_iHiddenDelay = m_iHiddenMax ;
			return 1;
		}
		return 1;
	}
	else if ( m_hidden )		// it's a littel strange to name this var hidden( I don't know 
	{
		
		// another magic num here//every frame to decrease 1,just pass it - u can tune maxdelaynumber to ...
		m_iHiddenDelay -= 1;
		if (EnemyObj::CanReappear() && (m_iHiddenDelay < 0) ) //(m_iHiddenDelay < 0) ) //
			//&& game not over// I choose not to use GameStates for this demo ,cause I want it simply DEC 17 3pm
		{
			//reappear!
			D3DXVECTOR3		v(-(   (rand()%50)/50.0f +0.5f)*(MAXENEMYVEL ) , 0.0f ,0.0f );
			Appear(int(SCREEN_OFFSET/640* (g_pGame->GetWidth())+ (g_pGame->GetWidth())) , rand()%g_pGame->GetHeight() , &v);
			UpdateMatrix();			//it's essenstial to avoid some artifacts
			++ iTotalEnemy  ;
			//reset the delay count
			m_iHiddenDelay = MAXHIDDENDELAY + rand()%MAXHIDDENDELAY ;
		}
		else
		{
			//wait do nothing 

		}
		return 1;
	}
	return 1;
}