#include "dxstdafx.h"
#include "DXUT.h"
#include "stdio.h"
#include "stdlib.h"
#include "FxComposer.h"
#include "Helpers.h"

const UINT mipmapLevel = 10; 

HRESULT CFxComposer::OnCreateDevice( IDirect3DDevice9* pd3dDevice , LPCSTR filename)
{
    HRESULT hr;

    //Add d3dDevice
    m_pd3dDevice = pd3dDevice;
    m_pd3dDevice->AddRef(); //release ondestory

    // Define DEBUG_VS and/or DEBUG_PS to debug vertex and/or pixel shaders with the 
    // shader debugger. Debugging vertex shaders requires either REF or software vertex 
    // processing, and debugging pixel shaders requires REF.  The 
    // D3DXSHADER_FORCE_*_SOFTWARE_NOOPT flag improves the debug experience in the 
    // shader debugger.  It enables source level debugging, prevents instruction 
    // reordering, prevents dead code elimination, and forces the compiler to compile 
    // against the next higher available software target, which ensures that the 
    // unoptimized shaders do not exceed the shader model limitations.  Setting these 
    // flags will cause slower rendering since the shaders will be unoptimized and 
    // forced into software.  See the DirectX documentation for more information about 
    // using the shader debugger.
    DWORD dwShaderFlags = D3DXFX_NOT_CLONEABLE;

#if defined( DEBUG ) || defined( _DEBUG )
    // Set the D3DXSHADER_DEBUG flag to embed debug information in the shaders.
    // Setting this flag improves the shader debugging experience, but still allows 
    // the shaders to be optimized and to run exactly the way they will run in 
    // the release configuration of this program.
    dwShaderFlags |= D3DXSHADER_DEBUG;
    // Skip the optimization for debugging
    dwShaderFlags |= D3DXSHADER_SKIPOPTIMIZATION;
#endif

    // Preshaders are parts of the shader that the effect system pulls out of the 
    // shader and runs on the host CPU. They should be used if you are GPU limited. 
    // The D3DXSHADER_NO_PRESHADER flag disables preshaders.
    //if( !g_bEnablePreshader )
    dwShaderFlags |= D3DXSHADER_NO_PRESHADER;

    // If this fails, there should be debug output as to 
    // why the .fx file failed to compile

    LPD3DXBUFFER  pBuffer=NULL;
    char fxname[MAX_PATH] = {0};
    FindResourceFile(filename, fxname);
    hr = ( D3DXCreateEffectFromFileA( pd3dDevice, fxname, NULL, NULL, dwShaderFlags, NULL, &g_pEffect, &pBuffer ) );

    //Dump all the errors to debug files
    if (hr != S_OK && pBuffer)
    {
        char* errorMsg = NULL;
        errorMsg = (char*)pBuffer->GetBufferPointer();
        DumpErrorMsg(errorMsg,"shaderCompilationError");

        //TODO: abruptly quit!?
        exit(0);
    }


    AddPassNameFromFxFile();

    //Load Necessary Meshes
    AddMeshFromXFileFoundInDefaultDirectory("Sphere");
    AddMeshFromXFileFoundInDefaultDirectory("ScreenAlignedQuad");


    //Load Texture
    AddStaticTextureByShaderVariableName("grace_cube_Tex",STexture::ETexType::eTT_Cube);
    GetTexture("grace_cube_Tex")->dxTex->SetAutoGenFilterType(D3DTEXF_GAUSSIANQUAD);
    AddStaticTextureByShaderVariableName("earth_Tex",STexture::ETexType::eTT_2D);
    AddStaticTextureByShaderVariableName("cylinder_Tex",STexture::ETexType::eTT_2D);
    AddStaticTextureByShaderVariableName("vol_Tex",STexture::ETexType::eTT_3D);
    LoadMatlabTexture("frontBTDF_Tex");
    LoadMatlabTexture("backBTDF_Tex");

    //Add rendertarget
    AddRenderTarget("Oliveira", PowerOfUNIT(2,mipmapLevel-1), 
        PowerOfUNIT(2,mipmapLevel-1),true,D3DFMT_A8R8G8B8,0,1.0f);
    //AddRenderTarget("BackNormal", 640, 480);

    //Add downsample texture series
    AddDownsampleRenderTarget("BackMaxDepth",mipmapLevel,2,D3DFMT_R32F,0,1.0f);
    AddDownsampleRenderTarget("BackMinDepth",mipmapLevel,2,D3DFMT_R32F,0,1.0f);

    AddDownsampleRenderTarget("1stQuadrant",mipmapLevel,2,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0));
    AddDownsampleRenderTarget("2ndQuadrant",mipmapLevel,2,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0));
    AddDownsampleRenderTarget("3rdQuadrant",mipmapLevel,2,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0));
    AddDownsampleRenderTarget("4thQuadrant",mipmapLevel,2,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0));

    AddRenderTarget("BackNormal",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),true,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(255,127,127,127),0.0f);
    AddRenderTarget("BackRoughness",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),true,D3DFMT_A8R8G8B8,0,0.0f);

    AddRenderTarget("1stQuadrantNormal",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),false,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0),1.0f,true);
    AddRenderTarget("2ndQuadrantNormal",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),false,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0),1.0f,true);
    AddRenderTarget("3rdQuadrantNormal",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),false,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0),1.0f,true);
    AddRenderTarget("4thQuadrantNormal",PowerOfUNIT(2,mipmapLevel-1),
        PowerOfUNIT(2,mipmapLevel-1),false,D3DFMT_A32B32G32R32F,D3DCOLOR_ARGB(0,127,127,0),1.0f,true);

    return S_OK;
}

HRESULT CFxComposer::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{

    //Update d3dDevice
    //m_pd3dDevice = pd3dDevice;

    HRESULT hr;
    // Reset Effect
    if( g_pEffect )
        V_RETURN( g_pEffect->OnResetDevice() );

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 2.0f, 4000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
    g_Camera.SetButtonMasks( MOUSE_LEFT_BUTTON, MOUSE_WHEEL, MOUSE_RIGHT_BUTTON );

    return S_OK;
}

void CFxComposer::OnFrameMove(  double fTime, float fElapsedTime )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );
}

void CFxComposer::OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime )
{

    //Update d3dDevice
    //m_pd3dDevice = pd3dDevice;

    HRESULT hr;
    SetupCameraMatrix();

    // Apply the technique contained in the effect 
    UINT iPass, cPasses;
    V( g_pEffect->Begin(&cPasses, 0) );

    //-------------------------------------------------------------------------
    // LET'S BEGIN RENDERING!
    //-------------------------------------------------------------------------
    //TODO: change this to scripts
    //-------------------------------------------------------------------------
    // [ 1 ] this pass is used for render to target!
    //-------------------------------------------------------------------------
    BeginPassByName("BackDepth");
    {
        // ID3DXRenderToSurface
        // The effect interface queues up the changes and performs them 
        // with the CommitChanges call. You do not need to call CommitChanges if 
        // you are not setting any parameters between the BeginPass and EndPass.
        // V( g_pEffect->CommitChanges() );

        // Render the mesh with the applied technique
        //V( DrawMeshBySemantic(GetRenderedMeshName().c_str()));
        BeginRenderTarget("BackMaxDepth0",0,0);
        //clear texture
        m_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,0,0.0f,0);
        V( DrawMeshByName(GetRenderedMeshName().c_str()));
        EndRenderTarget();
        BeginRenderTarget("BackMinDepth0",0,0);
        m_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,0,0.0f,0);
        V( DrawMeshByName(GetRenderedMeshName().c_str()));

        EndRenderTarget();
    }
    EndPassByName();




    //-------------------------------------------------------------------------
    // [ 2 ] Render back normals and roughness( in fact color map, we need RGB8
    //      's RED channel)
    //-------------------------------------------------------------------------
    BeginPassByName("BackNormal");
    {
        BeginRenderTarget("BackNormal",0,0);
        V( DrawMeshByName(GetRenderedMeshName().c_str()));
        EndRenderTarget();
    }
    EndPassByName();
    BeginPassByName("BackRoughness");
    {
        BeginRenderTarget("BackRoughness",0,0);
        V( DrawMeshByName(GetRenderedMeshName().c_str()));
        EndRenderTarget();
    }
    EndPassByName();


    //-------------------------------------------------------------------------
    // [ 3 ] Z Min & Max
    //-------------------------------------------------------------------------
    for (UINT i = 0; i < mipmapLevel-1; ++i)
    {
        //downsample to a smaller one texture
        BeginPassByName("MinMax");
        {
            //2 render target for Min Max shader
            BeginDownsampleRenderTarget("BackMaxDepth",i+1,0);
            BeginDownsampleRenderTarget("BackMinDepth",i+1,1);

            g_pEffect->SetTexture("back_MaxTex",GetDownsampleRenderTarget("BackMaxDepth",i)->dxTex);
            g_pEffect->SetTexture("back_MinTex",GetDownsampleRenderTarget("BackMinDepth",i)->dxTex);

            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-i-2)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-i-2)));


            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName("ScreenAlignedQuad"));

            EndDownsampleRenderTarget(0);
            EndDownsampleRenderTarget(1);
        }
        EndPassByName();
    }

    if (m_renderedTechName != "LEAN")
    {
        //-------------------------------------------------------------------------
        // [ 4 ] Split
        //-------------------------------------------------------------------------
        //downsample to a smaller one texture
        BeginPassByName("Split");
        {
            //2 render target for Min Max shader
            BeginDownsampleRenderTarget("1stQuadrant",0,0);
            BeginDownsampleRenderTarget("2ndQuadrant",0,1);
            BeginDownsampleRenderTarget("3rdQuadrant",0,2);
            BeginDownsampleRenderTarget("4thQuadrant",0,3);

            g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);
            g_pEffect->SetTexture("backRoughness_Tex",GetRenderTarget("BackRoughness")->dxTex);

            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));

            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName("ScreenAlignedQuad"));

            EndDownsampleRenderTarget(0);
            EndDownsampleRenderTarget(1);
            EndDownsampleRenderTarget(2);
            EndDownsampleRenderTarget(3);
        }
        EndPassByName();


        //-------------------------------------------------------------------------
        // [ 5 ] Merge to Mipmap
        //-------------------------------------------------------------------------
        MergeRenderTargetHelper("1stQuadrant","Merge");
        MergeRenderTargetHelper("2ndQuadrant","Merge");
        MergeRenderTargetHelper("3rdQuadrant","Merge");
        MergeRenderTargetHelper("4thQuadrant","Merge");
    }
    else
    {
        //-------------------------------------------------------------------------
        // [ 5 ] LEAN map
        //-------------------------------------------------------------------------

        BeginPassByName("Lean");
        {
            //2 render target for Min Max shader
            BeginDownsampleRenderTarget("1stQuadrant",0,0);
            BeginDownsampleRenderTarget("2ndQuadrant",0,1);

            g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);
            g_pEffect->SetTexture("backRoughness_Tex",GetRenderTarget("BackRoughness")->dxTex);

            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));

            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName("ScreenAlignedQuad"));

            EndDownsampleRenderTarget(0);
            EndDownsampleRenderTarget(1);
            //
        }
        EndPassByName();

        MergeRenderTargetHelper("1stQuadrant","LeanDownsample");
        MergeRenderTargetHelper("2ndQuadrant","LeanDownsample");
    }

    //-------------------------------------------------------------------------
    // [ 6 ] copy Merge map to a normal mipmap texture for later use
    //-------------------------------------------------------------------------
    CopyMerge2RTTexture("1stQuadrant","1stQuadrantNormal");
    CopyMerge2RTTexture("2ndQuadrant","2ndQuadrantNormal");
    CopyMerge2RTTexture("3rdQuadrant","3rdQuadrantNormal");
    CopyMerge2RTTexture("4thQuadrant","4thQuadrantNormal");

    //-------------------------------------------------------------------------
    // [ ? ] Oliveira test
    //-------------------------------------------------------------------------
    BeginPassByName("OliveiraTestPass");
    {
        BeginRenderTarget("Oliveira",0);


        m_pd3dDevice->Clear(0,
            NULL,
            D3DCLEAR_ZBUFFER, //No stencil needed to be cleared
            D3DCOLOR_ARGB(0xff,0xff,0xff,0xff),
            1.0f,
            0);
        g_pEffect->SetTexture("backDepth_Tex",GetDownsampleRenderTarget("BackMaxDepth",0)->dxTex);
        g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);
        g_pEffect->SetTexture("downsample_MinTex",GetDownsampleRenderTarget("BackMinDepth",mipmapLevel-1)->dxTex);
        g_pEffect->SetTexture("downsample_MaxTex",GetDownsampleRenderTarget("BackMaxDepth",mipmapLevel-1)->dxTex);

        SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));
        SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));

        V( g_pEffect->CommitChanges() );
        V( DrawMeshByName(GetRenderedMeshName().c_str()));


        EndRenderTarget();
    }
    EndPassByName();

    //-------------------------------------------------------------------------
    // [ 7 ] Final Pass
    //-------------------------------------------------------------------------
    if(m_renderedTechName != "LEAN")
    {
        BeginPassByName("FinalPass");
        {
            m_pd3dDevice->Clear(0,
                NULL,
                D3DCLEAR_ZBUFFER, //No stencil needed to be cleared
                D3DCOLOR_ARGB(0xff,0xff,0xff,0xff),
                1.0f,
                0);
            g_pEffect->SetTexture("backDepth_Tex",GetDownsampleRenderTarget("BackMaxDepth",0)->dxTex);
            g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);
            g_pEffect->SetTexture("downsample_MinTex",GetDownsampleRenderTarget("BackMinDepth",mipmapLevel-1)->dxTex);
            g_pEffect->SetTexture("downsample_MaxTex",GetDownsampleRenderTarget("BackMaxDepth",mipmapLevel-1)->dxTex);

            g_pEffect->SetTexture("back_1stMergeTex",GetRenderTarget("1stQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_2ndMergeTex",GetRenderTarget("2ndQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_3rdMergeTex",GetRenderTarget("3rdQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_4thMergeTex",GetRenderTarget("4thQuadrantNormal")->dxTex);


            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));

            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName(GetRenderedMeshName().c_str()));


            EndRenderTarget();
        }
        EndPassByName();

    }
    else
    {
        BeginPassByName("LeanFinalPass");
        {
            m_pd3dDevice->Clear(0,
                NULL,
                D3DCLEAR_ZBUFFER, //No stencil needed to be cleared
                D3DCOLOR_ARGB(0xff,0xff,0xff,0xff),
                1.0f,
                0);
            g_pEffect->SetTexture("backDepth_Tex",GetDownsampleRenderTarget("BackMaxDepth",0)->dxTex);
            g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);
            g_pEffect->SetTexture("downsample_MinTex",GetDownsampleRenderTarget("BackMinDepth",mipmapLevel-1)->dxTex);
            g_pEffect->SetTexture("downsample_MaxTex",GetDownsampleRenderTarget("BackMaxDepth",mipmapLevel-1)->dxTex);

            g_pEffect->SetTexture("back_1stMergeTex",GetRenderTarget("1stQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_2ndMergeTex",GetRenderTarget("2ndQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_3rdMergeTex",GetRenderTarget("3rdQuadrantNormal")->dxTex);
            g_pEffect->SetTexture("back_4thMergeTex",GetRenderTarget("4thQuadrantNormal")->dxTex);


            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-1)));

            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName(GetRenderedMeshName().c_str()));


            EndRenderTarget();
        }
        EndPassByName();

    }
    // [ 8 ] Render background!
    BeginPassByName("Background");
    V( DrawMeshByName("Sphere"));
    EndPassByName();

    //-------------------------------------------------------------------------
    // END RENDERING
    //-------------------------------------------------------------------------



    V( g_pEffect->End() );

    //Render some target here
    //Clear Depth ONLY
    m_pd3dDevice->Clear(0,
        NULL,
        D3DCLEAR_ZBUFFER, //No stencil needed to be cleared
        D3DCOLOR_ARGB(0xff,0xff,0xff,0xff),
        1.0f,
        0);
    UINT uiHeight = PowerOfUNIT(2,mipmapLevel-1)/4; UINT uiWidthTotal = 0;UINT uiHeightTotal = 0;
    float renderScale = 0.25f;
    DrawRenderTargetToScreen("Oliveira",uiWidthTotal=0,uiHeightTotal=PowerOfUNIT(2,mipmapLevel-1) -uiHeight/2,2*renderScale);

}

LRESULT CFxComposer::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    // Pass all remaining windows messages to camera so it can respond to user input
    return g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

}

void CFxComposer::OnLostDevice()
{
    if( g_pEffect )
        g_pEffect->OnLostDevice();
}

void CFxComposer::OnDestroyDevice()
{
    SAFE_RELEASE(g_pEffect);

    //Mesh list
    for (TMeshList::iterator meshIt = m_meshList.begin(); meshIt != m_meshList.end(); ++meshIt)
    {
        SAFE_RELEASE(meshIt->second->dxMesh);
        //SAFE_RELEASE(meshIt->second->meshTexture);
        SAFE_DELETE(meshIt->second);
    }
    //Texture List
    for (TTextureList::iterator texIt = m_texList.begin(); texIt != m_texList.end(); ++texIt)
    {
        SAFE_RELEASE(texIt->second->dxTex);
        SAFE_DELETE(texIt->second);
    }

    //Render Target list
    for (TRenderTargetList::iterator rtIt = m_renderTargetList.begin(); rtIt != m_renderTargetList.end(); ++rtIt)
    {
        SAFE_RELEASE(rtIt->second->dxTex);
        SAFE_DELETE(rtIt->second);
    }

    m_meshList.clear();
    m_texList.clear();
    m_renderTargetList.clear();
    m_passIndexList.clear();

    m_pd3dDevice->Release();
    m_pd3dDevice = NULL;
    //Name
    m_renderedMeshName = "";
    m_renderedTechName = "";
}
void CFxComposer::MergeRenderTargetHelper( LPCSTR targetGroupName, LPCSTR passName )
{
    HRESULT hr;
    for (UINT i = 0; i < mipmapLevel-1; ++i)
    {
        //downsample to a smaller one texture
        BeginPassByName(passName);
        {
            //2 render target for Min Max shader
            BeginDownsampleRenderTarget(targetGroupName,i+1,0);

            g_pEffect->SetTexture("back_MergeTex",GetDownsampleRenderTarget(targetGroupName,i)->dxTex);
            g_pEffect->SetTexture("backNormal_Tex",GetRenderTarget("BackNormal")->dxTex);


            SetFloatByFxSemantic("ViewportWidthInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-i-2)));
            SetFloatByFxSemantic("ViewportHeightInverse", 1.0f/float(PowerOfUNIT(2,mipmapLevel-i-2)));
            SetFloat("lodLevel",i+1);

            V( g_pEffect->CommitChanges() );
            V( DrawMeshByName("ScreenAlignedQuad"));

            EndDownsampleRenderTarget(0);
        }
        EndPassByName();
    }
}

void CFxComposer::CopyMerge2RTTexture( LPCSTR targetGroupName, LPCSTR textureName )
{
    HRESULT hr;

    IDirect3DSurface9 *ptrSurfSrc = NULL, *ptrSurfDest = NULL;
    IDirect3DTexture9 *ptrTexSrc = NULL, *ptrTexDest = NULL;
    //Get DX9 texture
    ptrTexDest = (IDirect3DTexture9 *)GetRenderTarget(textureName)->dxTex;

    for (UINT i=0; i < mipmapLevel; ++i)
    {
        //get downsample group texture
        ptrTexSrc = GetDownsampleRenderTarget(targetGroupName,i)->dxTex;
        //Get Surface
        hr = (ptrTexSrc->GetSurfaceLevel(0,&ptrSurfSrc));
        hr = (ptrTexDest->GetSurfaceLevel(i,&ptrSurfDest));
        //Copy
        hr = (m_pd3dDevice->StretchRect(ptrSurfSrc,NULL,ptrSurfDest,NULL,D3DTEXF_NONE));

        SAFE_RELEASE(ptrSurfDest);
        SAFE_RELEASE(ptrTexSrc);
    }
}

HRESULT CFxComposer::LoadMatlabTexture(LPCSTR texVarName)
{
    if (texVarName)
    {
        HRESULT hr;
        //TODO: load format in txt file
        UINT width, height;
        float* ptrFloatArray=NULL;
        STexture* ptrTempTex = new STexture;
        //TODO: Type must be 2D?
        ptrTempTex->texType = STexture::ETexType::eTT_2D;

        char fname[_MAX_FNAME]={0}; 
        //TODO: Add more texture
        LPCSTR tsz = 0; //TODO: DX release this data?
        //if(!texHandle) return S_FALSE;
        D3DXHANDLE texStringHandle = g_pEffect->GetAnnotationByName(texVarName,"ResourceName");
        if(!texStringHandle) return S_FALSE;
        V_RETURN( g_pEffect->GetString(texStringHandle,&tsz));
        FindResourceFile(tsz,fname);


        LoadMatlabTxtAsFloatMatrix(fname,&width,&height,&ptrFloatArray);
        //Create Texture

        LPDIRECT3DTEXTURE9 tex;
        V(D3DXCreateTexture(m_pd3dDevice, width, height,0, 
            D3DUSAGE_AUTOGENMIPMAP, D3DFMT_A32B32G32R32F, D3DPOOL_MANAGED, &tex));

        D3DLOCKED_RECT lock;
        float* pData = NULL;
        UINT size = 0;

        V(tex->LockRect(0,&lock,NULL,NULL));

        pData=(float *)lock.pBits;
        for (UINT i = 0; i < width; ++i)
        {
            for (UINT j = 0; j < height; ++j)
            {
                for (UINT k = 0; k < 4; ++k)
                {
                    *pData = ptrFloatArray[(i*width + j)*4+k];
                    ++pData;
                }
            }
        }

        V(tex->UnlockRect(0));
        //mip map
        V(tex->SetAutoGenFilterType(D3DTEXF_LINEAR));
        tex->GenerateMipSubLevels();
        //Add texture 
        ptrTempTex->dxTex = tex;
        //Add texture to its SMesh
        m_texList.insert(TTextureList::value_type(texVarName, ptrTempTex));

        //Add texture name to its coorresponding texture
        V_RETURN( g_pEffect->SetTexture(texVarName , ptrTempTex->dxTex) );

        //Clean
        delete [] ptrFloatArray;
    }
    return S_OK;

}


void CFxComposer::ChangeMeshTo( LPCSTR meshName )
{
    m_renderedMeshName = meshName;
    SMesh* tempMesh = GetMesh(meshName);
    if (tempMesh)
    {
        SetObjectAsCameraCenter(tempMesh->vCenter,tempMesh->fObjectRadius);
    }
}

void CFxComposer::ChangeTechTo( LPCSTR techName )
{
    m_renderedTechName = techName;
}

void CFxComposer::AddPassNameFromFxFile( LPCSTR fxFileName )
{
    HRESULT hr;
    //Get Pass Name and index it!
    V( g_pEffect->Begin(&m_passTotalNumber, 0) );
    D3DXPASS_DESC tmpDesc;
    for (UINT iPass = 0; iPass < m_passTotalNumber; iPass++)
    {
        D3DXHANDLE passHandle = g_pEffect->GetPass(g_pEffect->GetTechnique(0),iPass);
        V(g_pEffect->GetPassDesc(passHandle,&tmpDesc));
        m_passIndexList.insert(TPassIndexList::value_type(tmpDesc.Name, iPass));
    }
    V( g_pEffect->End() );
}
HRESULT CFxComposer::DrawMeshByName( LPCSTR meshName )
{
    HRESULT hr;
    SMesh* tempMesh = GetMesh(meshName);
    V_RETURN( tempMesh->dxMesh->DrawSubset(0) );
}
