#ifndef Helpers_h__
#define Helpers_h__

//Load matlab exported txt matrix file
bool LoadMatlabTxtAsFloatMatrix(LPCSTR fileName, UINT* outputWidth, UINT* outputHeight, float** outputFloatArrayPtr,LPCSTR format = "floatx4" );

//Find the resources from the file path name, you could input absolute path or relative path
//  it'll retrieve the absolute path of the found file. ONLY find the FIRST file!
bool FindResourceFile(LPCSTR fileName, LPSTR outputAbsoutePath);

//Compute Power of UINT
UINT PowerOfUNIT(UINT  x, UINT  p);

//Simple Dump Error Information
void DumpErrorMsg(LPCSTR errorMsg, LPCSTR fileName);

#endif // Helpers_h__