#include "dxstdafx.h"
#include "DXUT.h"
#include "stdio.h"
#include "stdlib.h"
#include "FxComposer.h"
#include "Helpers.h"

CFxComposer::SMesh* CFxComposer::GetMesh( LPCSTR meshName )
{
    HRESULT hr;
    char* tempLowerMeshName = _strdup(meshName);
    _strlwr(tempLowerMeshName);
    //Get RenderTarget 
    SMesh* ptrMesh = NULL;

    if (m_meshList.count(tempLowerMeshName) == 0)
    {
        hr = AddMeshFromXFileFoundInDefaultDirectory(tempLowerMeshName);
    }

    TMeshList::iterator it;
    if (m_meshList.count(tempLowerMeshName) == 0)
    {
        it = m_meshList.begin();
    }
    else
    {
        it = m_meshList.find(tempLowerMeshName);
    }
    ptrMesh = it->second;

    free(tempLowerMeshName);

    return ptrMesh;

}
HRESULT CFxComposer::AddMeshFromFile( LPCSTR fileName, bool asCenterObject/*=false*/ )
{
    //TODO: check if the mesh has been loaded
    HRESULT hr;
    SMesh* ptrNewMesh = new SMesh();

    if(fileName)
    {
        // Load the mesh
        ID3DXMesh* tempPtrMesh;
        V_RETURN( LoadMeshFromXFile( m_pd3dDevice, fileName , &tempPtrMesh ) );

        //Add mesh pointer to SMesh
        ptrNewMesh->dxMesh = tempPtrMesh;

        //Get center and radius
        D3DXVECTOR3* pData; 
        D3DXVECTOR3 vCenter;
        float fObjectRadius = 0;
        V( tempPtrMesh->LockVertexBuffer( 0, (LPVOID*) &pData ) );
        V( D3DXComputeBoundingSphere( pData, tempPtrMesh->GetNumVertices(), D3DXGetFVFVertexSize( tempPtrMesh->GetFVF() ), &vCenter, &fObjectRadius ) );
        V( tempPtrMesh->UnlockVertexBuffer() );
        ptrNewMesh->fObjectRadius = fObjectRadius;
        ptrNewMesh->vCenter = vCenter;

        //SPlit path and filename
        char szFName[255] = {0};
        _splitpath(fileName, 0, 0, szFName, 0);
        m_meshList.insert(TMeshList::value_type(szFName, ptrNewMesh));

        return S_OK;

    }

    return S_OK;
}

HRESULT CFxComposer::LoadMeshFromXFile( IDirect3DDevice9* pd3dDevice, LPCSTR strFileName, ID3DXMesh** ppMesh )
{
    //--------------------------------------------------------------------------------------
    // This function loads the mesh and ensures the mesh has normals; it also optimizes the 
    // mesh for the graphics card's vertex cache, which improves performance by organizing 
    // the internal triangle list for less cache misses.
    //--------------------------------------------------------------------------------------
    ID3DXMesh* pMesh = NULL;
    HRESULT hr;

    // Load the mesh with D3DX and get back a ID3DXMesh*.  For this
    // sample we'll ignore the X file's embedded materials since we know 
    // exactly the model we're loading.  See the mesh samples such as
    // "OptimizedMesh" for a more generic mesh loading example.
    V_RETURN( D3DXLoadMeshFromXA( strFileName, D3DXMESH_MANAGED, pd3dDevice, NULL, NULL, NULL, NULL, &pMesh ) );

    DWORD* rgdwAdjacency = NULL;

    // Make sure there are normals which are required for lighting
    // TODO: make sure you'll have targent and other vertex attribute
    if( !( pMesh->GetFVF() & D3DFVF_NORMAL ) )
    {
        ID3DXMesh* pTempMesh;
        V( pMesh->CloneMeshFVF( pMesh->GetOptions(),
            pMesh->GetFVF() | D3DFVF_NORMAL,
            pd3dDevice, &pTempMesh ) );
        V( D3DXComputeNormals( pTempMesh, NULL ) );

        SAFE_RELEASE( pMesh );
        pMesh = pTempMesh;
    }

    // Optimize the mesh for this graphics card's vertex cache 
    // so when rendering the mesh's triangle list the vertices will 
    // cache hit more often so it won't have to re-execute the vertex shader 
    // on those vertices so it will improve perf.     
    rgdwAdjacency = new DWORD[pMesh->GetNumFaces() * 3];
    if( rgdwAdjacency == NULL )
        return E_OUTOFMEMORY;
    V( pMesh->GenerateAdjacency( 1e-6f, rgdwAdjacency ) );
    V( pMesh->OptimizeInplace( D3DXMESHOPT_VERTEXCACHE, rgdwAdjacency, NULL, NULL, NULL ) );
    delete []rgdwAdjacency;

    *ppMesh = pMesh;

    return S_OK;

}
HRESULT CFxComposer::AddMeshFromXFileFoundInDefaultDirectory( LPCSTR fileName )
{
    //We could only support .x file now!
    char fileNameWithoutExt[255] = {0};
    char fileExtName[255] = {0};
    _splitpath(fileName, 0, 0, fileNameWithoutExt, fileExtName);
    strcat(fileNameWithoutExt, ".x");

    //Find file
    char fullPath[MAX_PATH] = {0};
    if(!FindResourceFile(fileNameWithoutExt,fullPath))
    {
        //no such file
        return S_FALSE;
    }

    //Load this file and name it to its filename..
    return AddMeshFromFile(fullPath);
}
