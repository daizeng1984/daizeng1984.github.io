#ifndef FxComposer_h__
#define FxComposer_h__


#include "dxut.h"
#include "DXUTgui.h"
#include "DXUTmisc.h"
#include <vector>
#include <string>
#include <map>


//load effect and display this effect
class CFxComposer
{
private:

    //TODO: refactor below to class
    //Mesh, Texture
    struct SMesh
    {
        ID3DXMesh*              dxMesh; //simply use DX's default mesh
        D3DXVECTOR3             vCenter;
        float                   fObjectRadius;
        std::vector<IDirect3DTexture9*>      meshTexture; //texture that belong to mesh
        SMesh():dxMesh(NULL),vCenter(0,0,0){} 
    };

    //Normal Texture not used for rendertarget
    struct STexture
    {
        IDirect3DBaseTexture9 *       dxTex;
        enum ETexType
        {
            eTT_2D = 0,
            eTT_Cube,
            eTT_3D,
            eTT_TotalTypeNumber,
            eTT_unknown
        };
        ETexType    texType;
        STexture():dxTex(NULL),texType(eTT_unknown){}
    };
    //RenderTarget
    struct SRenderTarget
    {
        IDirect3DTexture9 *       dxTex;
        UINT width;
        UINT height;
        D3DCOLOR clearColor;
        float clearDepth;

        SRenderTarget():dxTex(NULL),width(0),height(0),clearColor(0),clearDepth(0.0f){}
    };
    // Data Structure Definitions
    struct TLVertex
    {
        D3DXVECTOR4 p;
        D3DXVECTOR2 t;
        static const DWORD    FVF_TLVERTEX = D3DFVF_XYZRHW | D3DFVF_TEX1;
    };

public:
    CFxComposer();
    ~CFxComposer();
        
    //TODO: name should not lower uppper case sensitive.
    //Routine methods for DXUT
    HRESULT OnCreateDevice( IDirect3DDevice9* pd3dDevice , LPCSTR filename);
    HRESULT OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc);
    void OnFrameMove( double fTime, float fElapsedTime );
    void OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime);
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    void OnLostDevice();
    void OnDestroyDevice();


    //The two function shoudl always be together, notice we have only one Fx and only one
    //    Techniques! the name is the pass name in Fx file.
    void AddPassNameFromFxFile(LPCSTR fxFileName = NULL); //NULL for the default fx file
    void BeginPassByName(LPCSTR passNameInFxFile);
    void EndPassByName();


    //Load Mesh and put it into a list, semanticName is the mesh name in your fx semantic
    //    and TextureSemantic is the texture name, notice the name and fx's texture
    //    variable name should be the same!
    HRESULT AddMeshFromXFileFoundInDefaultDirectory(LPCSTR fileName);
    HRESULT AddMeshFromFile(LPCSTR fileName, bool asCenterObject=false); //if filename is "e:\foo\abc.x", the mesh name would be abc
    HRESULT DrawMeshByName(LPCSTR meshName);
    HRESULT LoadMeshFromXFile( IDirect3DDevice9* pd3dDevice, LPCSTR strFileName, ID3DXMesh** ppMesh );
    CFxComposer::SMesh* GetMesh( LPCSTR meshName );


    //Load Texture, given its shader variable name
    HRESULT AddStaticTextureByShaderVariableName(LPCSTR shaderVarName, STexture::ETexType texType = STexture::ETexType::eTT_2D);
    HRESULT AddTexture(LPCSTR textureName, UINT with, UINT height,bool mipmap = false, D3DFORMAT Format = D3DFMT_A8R8G8B8, STexture::ETexType texType = STexture::ETexType::eTT_2D);
    STexture* GetTexture(LPCSTR textureName);
    void DrawTextureToScreen(IDirect3DTexture9* textureBuffer,  UINT x  = 0, UINT y  = 0, float scale = 1.f, UINT level = 0 );


    //Add RenderTarget
    HRESULT AddRenderTarget(LPCSTR renderTargetName, UINT width, UINT height, bool mipmap = false, D3DFORMAT Format=D3DFMT_A8R8G8B8, D3DCOLOR color=0, float depth=1.0f, bool mipmapcopy=false);
    SRenderTarget* GetRenderTarget(LPCSTR renderTargetName);
    void BeginRenderTarget(LPCSTR renderTargetName, DWORD RenderTargetIndex , UINT level = 0);
    void EndRenderTarget(UINT index = 0);
    void DrawRenderTargetToScreen(LPCSTR renderTargetName,  UINT x  = 0, UINT y  = 0, float scale = 1.f, UINT level = 0 );


    //Downsample to 1x1 pixel! If size is 6, the largest texture is 2^5x2^5, user are 
    //    responsible to remember this size, you could use 0 to index the 2^5x2^5 
    //    largest tex, 5 for the 1x1 pixel
    HRESULT AddDownsampleRenderTarget(LPCSTR targetGroupName, UINT size, UINT base = 2, D3DFORMAT Format=D3DFMT_A8R8G8B8, D3DCOLOR color=0, float depth=1.0f);
    void BeginDownsampleRenderTarget(LPCSTR targetGroupName, UINT index, DWORD RenderTargetIndex = 0 , UINT level = 0);
    void EndDownsampleRenderTarget(UINT index = 0);
    SRenderTarget* GetDownsampleRenderTarget(LPCSTR targetGroupName, UINT index);
    

    //Change the fxcomposer's tech and mesh
    void ChangeTechTo(LPCSTR techName);
    void ChangeEnvmapTo(LPCTSTR envmapName);
    void ChangeMeshTo(LPCSTR meshName);

    //Set constant for shader by variable name
    bool SetMatrix(LPCSTR name, D3DXMATRIXA16& matrixValue);
    bool SetFloat4(LPCSTR name, D3DXVECTOR4& vectorValue);
    bool SetFloat(LPCSTR name, float floatValue);
    bool SetBool(LPCSTR name, bool value);


private:
    //Set constant for shader by fx semantic name
    void SetMatrixByFxSemantic(LPCSTR semanticName, D3DXMATRIX& matrixValue);
    void SetFloat4ByFxSemantic(LPCSTR semanticName, D3DXVECTOR4& vectorValue);
    void SetFloatByFxSemantic(LPCSTR semanticName, float value);

    //Mesh
    std::string GetRenderedMeshName(){return m_renderedMeshName;}

    //Texture
    HRESULT LoadMatlabTexture(LPCSTR texVarName);

    //Camera
    void SetupCameraMatrix();
    const CModelViewerCamera* GetCamera(){return &g_Camera;}
    void SetObjectAsCameraCenter(const D3DXVECTOR3& vCenter, float fObjectRadius);

    //Some hardcode logic
    //TODO: eliminate this by introducing scripts
    void MergeRenderTargetHelper(LPCSTR targetGroupName, LPCSTR passName);
    void CopyMerge2RTTexture(LPCSTR targetGroupName, LPCSTR textureName);

private:

    //TODO: change to a class

    typedef std::map<std::string, SMesh*>  TMeshList;
    typedef std::map<std::string, STexture*>  TTextureList;
    typedef std::map<std::string, SRenderTarget*>  TRenderTargetList;
    typedef std::map<std::string, UINT>     TPassIndexList;


    TMeshList m_meshList;
    TTextureList m_texList;
    TRenderTargetList m_renderTargetList;
    TPassIndexList m_passIndexList;

    //TODO:refactor all the function which has d3ddevice as parameter
    //TODO:initialize all these members!
    IDirect3DDevice9*       m_pd3dDevice;
    IDirect3DSurface9*      m_pBackBuffer; //used to store
    UINT                    m_passTotalNumber;
    D3DXMATRIXA16           g_mCenterWorld;
    CModelViewerCamera      g_Camera;               // A model viewing camera
    ID3DXEffect*            g_pEffect;       // D3DX effect interface
    std::string             m_renderedMeshName;
    std::string             m_renderedTechName;
    bool                    g_bEnablePreshader;     // if TRUE, then D3DXSHADER_NO_PRESHADER is used when compiling the shader
};
#endif // FxComposer_h__
