#include "dxstdafx.h"
#include "DXUT.h"
#include "stdio.h"
#include "stdlib.h"
#include "FxComposer.h"
#include "Helpers.h"

HRESULT CFxComposer::AddStaticTextureByShaderVariableName( LPCSTR shaderVarName, STexture::ETexType texType /*= STexture::ETexType::eTT_2D*/ )
{
    HRESULT hr;
    // Create the texture from a file
    if (shaderVarName)
    {
        STexture* ptrTempTex = new STexture;

        char fname[_MAX_FNAME] = {0}; 
        //TODO: Add more texture
        LPCSTR tsz = 0; //TODO: DX release this data?
        //if(!texHandle) return S_FALSE;
        D3DXHANDLE texStringHandle = g_pEffect->GetAnnotationByName(shaderVarName,"ResourceName");
        if(!texStringHandle) return S_FALSE;
        V_RETURN( g_pEffect->GetString(texStringHandle,&tsz));

        FindResourceFile(tsz,fname);


        //load tex for its type
        switch (texType)
        {
        case STexture::ETexType::eTT_2D:
            {
                IDirect3DTexture9 *      ptrMeshTexture = NULL;
                ptrTempTex->texType = STexture::ETexType::eTT_2D;
                D3DXIMAGE_INFO imgInfo; 
                V_RETURN( D3DXCreateTextureFromFileExA( m_pd3dDevice, fname, D3DX_DEFAULT, D3DX_DEFAULT, 
                    D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, 
                    D3DX_DEFAULT, D3DX_DEFAULT, 0, 
                    &imgInfo, NULL, &ptrMeshTexture ) );
                ptrTempTex->dxTex = ptrMeshTexture;
            }
            break;
        case STexture::ETexType::eTT_3D:
            {
                IDirect3DVolumeTexture9 *      ptrMeshTexture = NULL;
                D3DCAPS9 pCaps;
                ptrTempTex->texType = STexture::ETexType::eTT_3D;
                //m_pd3dDevice->GetDeviceCaps(&pCaps);
                //UINT p = pCaps.MaxVolumeExtent;
                V_RETURN( D3DXCreateVolumeTextureFromFileExA( m_pd3dDevice, fname, 
                    D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 
                    1,/*no mipmap*/ 0,D3DFMT_UNKNOWN, D3DPOOL_MANAGED, 
                    D3DX_DEFAULT, D3DX_DEFAULT, 0, 
                    NULL, NULL, &ptrMeshTexture ) );
                ptrTempTex->dxTex = ptrMeshTexture;                
            }
            break;
        case STexture::ETexType::eTT_Cube:
            {
                IDirect3DCubeTexture9 *      ptrMeshTexture = NULL;
                ptrTempTex->texType = STexture::ETexType::eTT_Cube;
                V_RETURN( D3DXCreateCubeTextureFromFileExA( 
                    m_pd3dDevice, fname, D3DX_DEFAULT, 
                    D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, 
                    D3DX_DEFAULT, D3DX_DEFAULT, 0, 
                    NULL, NULL, &ptrMeshTexture ) );
                ptrTempTex->dxTex = ptrMeshTexture;
            }
            break;
        default:
            {
                assert(0);
            }
            break;
        }


        //Add texture to its SMesh
        m_texList.insert(TTextureList::value_type(shaderVarName, ptrTempTex));

        //Add texture name to its coorresponding texture
        V_RETURN( g_pEffect->SetTexture(shaderVarName , ptrTempTex->dxTex) );
    }


    return S_OK;

}

HRESULT CFxComposer::AddTexture( LPCSTR textureName, UINT width, UINT height, bool mipmap, D3DFORMAT Format,STexture::ETexType texType /*= STexture::ETexType::eTT_2D*/ )
{
    HRESULT hr;
    // Create the texture from a file

    //TODO: check if it is mipmap true
    STexture* ptrTempTex = new STexture;

    //load tex for its type
    switch (texType)
    {
    case STexture::ETexType::eTT_2D:
        {
            IDirect3DTexture9 *      ptrMeshTexture;
            ptrTempTex->texType = STexture::ETexType::eTT_2D; 
            V_RETURN( m_pd3dDevice->CreateTexture(
                width,
                height,
                0,
                0,
                Format,
                D3DPOOL_DEFAULT,
                &ptrMeshTexture,
                NULL) );
            ptrTempTex->dxTex = ptrMeshTexture;
        }
        break;
    case STexture::ETexType::eTT_3D:
        {
            assert(0);
        }
        break;
    case STexture::ETexType::eTT_Cube:
        {
            //TODO: cubemap support
            assert(0);
        }
        break;
    default:
        {
            assert(0);
        }
        break;
    }

    //Add texture to its List
    m_texList.insert(TTextureList::value_type(textureName, ptrTempTex));

    return S_OK;
}
HRESULT CFxComposer::AddRenderTarget(LPCSTR renderTargetName, UINT width, UINT height, bool automipmap, D3DFORMAT Format, D3DCOLOR color, float depth, bool mipmapcopy )
{
    HRESULT hr;
    LPDIRECT3DTEXTURE9 pTex = NULL;
    if (automipmap)
    {
        V(m_pd3dDevice->CreateTexture(width, height, 
            0, //mipmap auto
            D3DUSAGE_RENDERTARGET | D3DUSAGE_AUTOGENMIPMAP,
            Format,
            D3DPOOL_DEFAULT, //must be default for rendertarget
            &pTex,
            NULL));
        if (pTex->GetLevelCount() <= 1)
        {
            hr = pTex->SetAutoGenFilterType(D3DTEXF_LINEAR);
            pTex->GenerateMipSubLevels();
        }
    }
    else if (mipmapcopy)
    {
        V(m_pd3dDevice->CreateTexture(width, height, 
            0, //mipmap auto
            D3DUSAGE_RENDERTARGET,
            Format,
            D3DPOOL_DEFAULT, //must be default for rendertarget
            &pTex,
            NULL));
        //if (pTex->GetLevelCount() <= 1)
        //{
        //    hr = pTex->SetAutoGenFilterType(D3DTEXF_LINEAR);
        //    pTex->GenerateMipSubLevels();
        //}
    }
    else
    {
        V(m_pd3dDevice->CreateTexture(width, height, 
            1, //no mipmap auto
            D3DUSAGE_RENDERTARGET,
            Format,
            D3DPOOL_DEFAULT, //must be default for rendertarget
            &pTex,
            NULL));

    }

    SRenderTarget* ptrRenderTarget = new SRenderTarget();
    ptrRenderTarget->dxTex = pTex;
    ptrRenderTarget->width = width;
    ptrRenderTarget->height = height;
    ptrRenderTarget->clearColor = color;
    ptrRenderTarget->clearDepth = depth;

    //Add rendertarget to its list
    //TODO: if rendertarget not exist.
    m_renderTargetList.insert(TRenderTargetList::value_type(renderTargetName, ptrRenderTarget));

    return S_OK;
}

//TODO: use level
void CFxComposer::DrawRenderTargetToScreen(LPCSTR renderTargetName, UINT x, UINT y, float scale, UINT level )
{
    //V(m_pd3dDevice->BeginScene());
    //Get RenderTarget 
    SRenderTarget* ptrRenderTarget = NULL;

    if (m_renderTargetList.count(renderTargetName)==1)
    {
        TRenderTargetList::iterator it= m_renderTargetList.find(renderTargetName);
        ptrRenderTarget = it->second;
    }
    //D3DSURFACE_DESC d;
    //pLDRSurface->GetDesc( &d );
    DrawTextureToScreen(ptrRenderTarget->dxTex,x,y,scale,level);

}

void CFxComposer::BeginRenderTarget( LPCSTR renderTargetName, DWORD RenderTargetIndex , UINT level)
{
    //Get RenderTarget 
    SRenderTarget* ptrRenderTarget = NULL;

    if (m_renderTargetList.count(renderTargetName)==1)
    {
        TRenderTargetList::iterator it= m_renderTargetList.find(renderTargetName);
        ptrRenderTarget = it->second;
    }

    LPDIRECT3DSURFACE9  pRenderSurface = NULL;
    ptrRenderTarget->dxTex->GetSurfaceLevel(level,&pRenderSurface);
    //Store the backbuffer
    if (!m_pBackBuffer)
    {
        m_pd3dDevice->GetRenderTarget(0,&m_pBackBuffer);
    }
    //Set some state as in rendermonkey's script
    //set new render target
    m_pd3dDevice->SetRenderTarget(RenderTargetIndex,pRenderSurface);
    //clear texture
    //TODO: Define a member indicating whether automatically clear backbuffer
    //  and respectively for buffer and depth etc.
    m_pd3dDevice->Clear(0,
        NULL,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, //No stencil needed to be cleared
        ptrRenderTarget->clearColor,
        ptrRenderTarget->clearDepth,
        0);

    //release
    pRenderSurface->Release();
}

void CFxComposer::EndRenderTarget(UINT index)
{

    //Restore back buffer    
    if (m_pBackBuffer && (index == 0))
    {
        m_pd3dDevice->SetRenderTarget(index,m_pBackBuffer);
        m_pBackBuffer->Release();
        m_pBackBuffer = NULL;
    }
    else
    {
        m_pd3dDevice->SetRenderTarget(index,NULL);
    }
}

HRESULT CFxComposer::AddDownsampleRenderTarget( LPCSTR targetGroupName, UINT size, UINT base, D3DFORMAT Format/*=D3DFMT_A8R8G8B8*/, D3DCOLOR color/*=0*/, float depth/*=1.0f*/ )
{
    CHAR name[256];
    for (UINT i = 0; i < size; ++i)
    {
        wsprintfA(name,"%s%d",targetGroupName,i);
        UINT texSize = PowerOfUNIT(base,size-i-1);
        AddRenderTarget(name,texSize,texSize,false,Format,color,depth);
    }
    return S_OK;
}

void CFxComposer::EndDownsampleRenderTarget(UINT index)
{
    EndRenderTarget(index);
}

void CFxComposer::BeginDownsampleRenderTarget( LPCSTR targetGroupName, UINT index, DWORD RenderTargetIndex /*= 0 */, UINT level /*= 0*/ )
{
    CHAR name[256];
    wsprintfA(name,"%s%d",targetGroupName,index);
    BeginRenderTarget(name,RenderTargetIndex,level);

}

CFxComposer::SRenderTarget* CFxComposer::GetRenderTarget( LPCSTR renderTargetName )
{
    //Get RenderTarget 
    SRenderTarget* ptrRenderTarget = NULL;

    if (m_renderTargetList.count(renderTargetName)==1)
    {
        TRenderTargetList::iterator it= m_renderTargetList.find(renderTargetName);
        ptrRenderTarget = it->second;
        return ptrRenderTarget;
    }

    return NULL;
}

CFxComposer::STexture* CFxComposer::GetTexture( LPCSTR textureName )
{
    //Get RenderTarget 
    STexture* ptrTex = NULL;

    if (m_texList.count(textureName)==1)
    {
        TTextureList::iterator it= m_texList.find(textureName);
        ptrTex = it->second;
        return ptrTex;
    }

    return NULL;

}
CFxComposer::SRenderTarget* CFxComposer::GetDownsampleRenderTarget( LPCSTR targetGroupName, UINT index )
{
    CHAR name[256];
    wsprintfA(name,"%s%d",targetGroupName,index);

    return GetRenderTarget(name);
}

void CFxComposer::DrawTextureToScreen( IDirect3DTexture9* textureBuffer, UINT x /*= 0*/, UINT y /*= 0*/, float scale /*= 1.f*/, UINT level /*= 0 */ )
{

    HRESULT hr;
    TLVertex v[4];

    v[0].t = D3DXVECTOR2( 0.0f, 0.0f );
    v[1].t = D3DXVECTOR2( 1.0f, 0.0f );
    v[2].t = D3DXVECTOR2( 0.0f, 1.0f );
    v[3].t = D3DXVECTOR2( 1.0f, 1.0f );
    V(m_pd3dDevice->SetPixelShader( NULL ));
    V(m_pd3dDevice->SetVertexShader( NULL ));
    V(m_pd3dDevice->SetFVF( TLVertex::FVF_TLVERTEX ));

    D3DSURFACE_DESC desc;
    textureBuffer->GetLevelDesc(0,&desc);

    float fWidth = float(desc.Width)*scale;
    float fHeight =float(desc.Height)*scale;

    v[0].p = D3DXVECTOR4( x, y, 0.0f, 1.0f );
    v[1].p = D3DXVECTOR4( fWidth+x, y, 0.0f, 1.0f );
    v[2].p = D3DXVECTOR4( x, fHeight +y, 0.0f, 1.0f );
    v[3].p = D3DXVECTOR4( fWidth+x, fHeight+y, 0.0f, 1.0f );


    //push
    DWORD zenable, zwriteenable;
    m_pd3dDevice->GetRenderState( D3DRS_ZENABLE, &zenable );
    m_pd3dDevice->GetRenderState( D3DRS_ZWRITEENABLE, &zwriteenable );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );


    hr = m_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
    hr = m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    //texture stage
    //m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    //m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    //m_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    //m_pd3dDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    //m_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    //m_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    //m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    //m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
    //m_pd3dDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_DISABLE );
    //m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    //matrix
    D3DXMATRIX matProj,matOldView, matOldProjection, matOldWorld;
    m_pd3dDevice->GetTransform(D3DTS_WORLD,&matOldWorld);
    m_pd3dDevice->GetTransform(D3DTS_VIEW,&matOldView);
    m_pd3dDevice->GetTransform(D3DTS_PROJECTION,&matOldProjection);
    D3DXMatrixIdentity(&matProj);
    m_pd3dDevice->SetTransform(D3DTS_WORLD, &matProj);
    m_pd3dDevice->SetTransform(D3DTS_VIEW, &matProj);
    //D3DXMatrixOrthoLH(&matProj, ptrRenderTarget->width, 
    //    ptrRenderTarget->height, -1.0f, 1.0f);
    m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);

    m_pd3dDevice->SetTexture( 0, textureBuffer );
    m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, v, sizeof( TLVertex ) );

    //pop
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, zenable );
    m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, zwriteenable );

    m_pd3dDevice->SetTransform(D3DTS_WORLD, &matOldWorld);
    m_pd3dDevice->SetTransform(D3DTS_VIEW, &matOldView);
    m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matOldProjection);
}

