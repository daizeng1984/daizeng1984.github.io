#include "dxstdafx.h"
#include "DXUT.h"
#include "stdio.h"
#include "stdlib.h"
#include "FxComposer.h"
void CFxComposer::SetObjectAsCameraCenter( const D3DXVECTOR3& vCenter, float fObjectRadius )
{
    D3DXMatrixTranslation( &g_mCenterWorld, -vCenter.x, -vCenter.y, -vCenter.z );
    D3DXMATRIXA16 m;
    D3DXMatrixRotationY( &m, D3DX_PI );
    g_mCenterWorld *= m;
    D3DXMatrixRotationX( &m, D3DX_PI / 2.0f );
    g_mCenterWorld *= m;

    // Setup the camera's view parameters
    D3DXVECTOR3 vecEye(0.0f, 0.0f, 15.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, 0.0f);
    g_Camera.SetViewParams( &vecEye, &vecAt );
    g_Camera.SetRadius( fObjectRadius*3.0f, fObjectRadius*0.5f, fObjectRadius*10.0f );

}




void CFxComposer::SetupCameraMatrix()
{
    D3DXMATRIX mWorldViewProjection;
    D3DXMATRIX mWorldView;
    D3DXMATRIX mWorldViewInverse;
    D3DXMATRIX mViewProjection;
    D3DXMATRIX mWorld;
    D3DXMATRIX mWorldInverse;
    D3DXMATRIX mView;
    D3DXMATRIX mViewInverse;
    D3DXMATRIX mProj;
    D3DXVECTOR4   vViewPos;

    // Get the projection & view matrix from the camera class
    mWorld = g_mCenterWorld * *g_Camera.GetWorldMatrix();
    mProj = *g_Camera.GetProjMatrix();
    mView = *g_Camera.GetViewMatrix();
    vViewPos = D3DXVECTOR4(*g_Camera.GetEyePt(),1.0f);

    mWorldViewProjection = mWorld * mView * mProj;
    mWorldView = mWorld * mView;
    mViewProjection = mView * mProj;
    D3DXMatrixInverse(&mWorldViewInverse,0,&mWorldView);
    D3DXMatrixInverse(&mViewInverse,0,&mView);
    D3DXMatrixInverse(&mWorldInverse,0,&mWorld);
    // Update the effect's variables.  Instead of using strings, it would 
    // be more efficient to cache a handle to the parameter by calling 
    // ID3DXEffect::GetParameterByName
    SetMatrixByFxSemantic("World",mWorld);
    SetMatrixByFxSemantic("Projection",mProj);
    SetMatrixByFxSemantic("View",mView);
    SetMatrixByFxSemantic("WorldViewProjection",mWorldViewProjection);
    SetMatrixByFxSemantic("WorldView", mWorldView);
    SetMatrixByFxSemantic("ViewProjection",mViewProjection);
    SetMatrixByFxSemantic("WorldViewInverse",mWorldViewInverse);
    SetMatrixByFxSemantic("ViewInverse",mViewInverse);
    SetFloat4ByFxSemantic("ViewPosition",vViewPos);


}
