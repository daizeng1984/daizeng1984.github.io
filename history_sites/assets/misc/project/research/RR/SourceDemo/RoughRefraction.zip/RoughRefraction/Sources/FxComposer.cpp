#include "dxstdafx.h"
#include "DXUT.h"
#include "stdio.h"
#include "stdlib.h"
#include "FxComposer.h"
#include "Helpers.h"


CFxComposer::CFxComposer()
: g_Camera(),
g_pEffect(NULL),
g_bEnablePreshader(FALSE),
m_pBackBuffer(NULL),
m_renderedMeshName("")
{
    D3DXMatrixIdentity(&g_mCenterWorld);
}
CFxComposer::~CFxComposer()
{
}


void CFxComposer::SetMatrixByFxSemantic( LPCSTR semanticName, D3DXMATRIX& matrixValue )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterBySemantic(NULL,semanticName);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetMatrix(semantichandle, &matrixValue ) );
    }
}

void CFxComposer::SetFloat4ByFxSemantic( LPCSTR semanticName, D3DXVECTOR4& vectorValue )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterBySemantic(NULL,semanticName);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetVector(semantichandle, &vectorValue ) );
    }
}

void CFxComposer::SetFloatByFxSemantic( LPCSTR semanticName, float value )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterBySemantic(NULL,semanticName);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetFloat(semantichandle, value ) );
    }
}
bool CFxComposer::SetMatrix( LPCSTR name, D3DXMATRIXA16& matrixValue )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterByName(NULL,name);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetMatrix(semantichandle, &matrixValue ) );
        return TRUE;
    }
    return FALSE;
}

bool CFxComposer::SetFloat4( LPCSTR name, D3DXVECTOR4& vectorValue )
{    
    D3DXHANDLE semantichandle = g_pEffect->GetParameterByName(NULL,name);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetVector(semantichandle, &vectorValue ) );
        return TRUE;
    }
    return FALSE;
}

bool CFxComposer::SetFloat( LPCSTR name, float floatValue )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterByName(NULL,name);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetFloat(semantichandle, floatValue) );
        return TRUE;
    }
    return FALSE;
}
bool CFxComposer::SetBool( LPCSTR name, bool value )
{
    D3DXHANDLE semantichandle = g_pEffect->GetParameterByName(NULL,name);
    if (semantichandle != NULL)
    {
        HRESULT hr;
        V( g_pEffect->SetBool(semantichandle, value) );
        return TRUE;
    }
    return FALSE;

}

void CFxComposer::BeginPassByName( LPCSTR passNameInFxFile )
{
    UINT iPass;
    TPassIndexList::iterator it= m_passIndexList.find(passNameInFxFile);
    if (m_passIndexList.count(passNameInFxFile)==1)
    {
        iPass = it->second;
        g_pEffect->BeginPass(iPass);
    }
}

void CFxComposer::EndPassByName()
{
    g_pEffect->EndPass();
}