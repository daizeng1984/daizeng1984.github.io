#include "dxstdafx.h"
#include "Helpers.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <direct.h>
#include <io.h>

UINT PowerOfUNIT( UINT x, UINT p )
{
    if(p == 0) return 1;
    if(x == 0) return 0;

    UINT  r = 1;
    for(;;) {
        if(p & 1) r *= x;
        if((p >>= 1) == 0)	return r;
        x *= x;
    }
}

bool LoadMatlabTxtAsFloatMatrix( LPCSTR fileName, UINT* outputWidth, UINT* outputHeight, float** outputFloatArrayPtr,LPCSTR format /*= "floatx4" */ )
{
    std::ifstream fin(fileName);
    std::string s;
    //no file exit?
    if(!fin)
        return false;
    //compute the row & column
    UINT row = 0;
    while(getline(fin,s))
    {
        ++row;
    }
    fin.clear();
    fin.seekg(0,std::ios::beg);
    UINT column = 0;
    getline(fin,s);
    float tempFloat= 0.0f;
    std::stringstream streamString;
    streamString << s;
    while(streamString >> tempFloat)
    {
        ++column;
    }
    fin.clear();
    fin.seekg(0,std::ios::beg);

    //load data and locate new mem for matrix
    float* outputFloatArray = NULL;
    if (strcmp(format,"floatx4")==0)
    {
        UINT strideLength = 4;
        row = row/strideLength;

        outputFloatArray = new float[row*column*strideLength];
        for (UINT k = 0; k < strideLength; ++k)
        {
            for( UINT i = 0; i < row; ++i )
            {
                for (UINT j = 0; j < column; ++j)
                {
                    fin >> outputFloatArray[(row*i + j)*strideLength + k];
                }
            }
        }
        *outputWidth = column;
        *outputHeight = row;
        *outputFloatArrayPtr = outputFloatArray;
    }
    else
    {
        assert(!"Not Support!");
        *outputWidth = 0;
        *outputHeight = 0;
        *outputFloatArrayPtr = 0;
        return false;
    }

    return true;

}
//download from website http://www.vimer.cn/2009/11/string%E6%9B%BF%E6%8D%A2%E6%89%80%E6%9C%89%E6%8C%87%E5%AE%9A%E5%AD%97%E7%AC%A6%E4%B8%B2%EF%BC%88c%EF%BC%89.html
std::string&   _InternalStringReplaceAll(std::string&   str,const   std::string&   old_value,const   std::string&   new_value)   
{   
    while(true)   {   
        std::string::size_type   pos(0);   
        if(   (pos=str.find(old_value))!=std::string::npos   )   
            str.replace(pos,old_value.length(),new_value);   
        else   break;   
    }   
    return   str;   
}   

bool _InternalFindFile( LPCSTR directory, LPCSTR filenameWithoutExt, LPCSTR extensition, LPSTR outputAbsoutePath, bool recursive = false )
{
    //copy directory and
    std::string path = directory;
    path = path + "\\";
    _InternalStringReplaceAll(path,"/","\\");
    _InternalStringReplaceAll(path,"\\\\","\\");

    //if no extension name
    char tempfileExt[255] = {0};
    if (*extensition == 0)
    {
         strcpy(tempfileExt,".*");
    }
    else
    {
        strcpy(tempfileExt,extensition);
    }

    //Find file in this direcotory recursively
    std::string temppath = path + filenameWithoutExt + tempfileExt;
    _finddata_t data;
    int handle = _findfirst(temppath.c_str(),&data);
    if(handle != -1 && data.attrib != _A_SUBDIR)
    {
        strcpy(outputAbsoutePath,(path + data.name).c_str());
        _findclose(handle);
        return true;
    }

    //no such file
    //get . handle
    handle = _findfirst((path+"*").c_str(),&data);
    //get subdirectory
    bool found = false;
    if(handle != -1 && recursive )
    {
        while (_findnext(handle,&data)!= -1)
        {
            if (data.attrib == _A_SUBDIR && strcmp(data.name,".") && strcmp(data.name,".."))
            {
                found = found || _InternalFindFile((path+data.name).c_str(),filenameWithoutExt,extensition,outputAbsoutePath,recursive);
            }
            if(found)
            {
                break;
            }

        }
    }
    _findclose(handle);

    return found;
}

bool FindResourceFile( LPCSTR fileName, LPSTR outputAbsoutePath )
{
    char fileNameWithoutExt[255] = {0};
    char fileExtName[255] = {0};
    char driver[255] = {0};
    char dir[255] = {0};
    char currentPathName[MAX_PATH] = {0}; //pathconf
    _splitpath(fileName, driver, dir, fileNameWithoutExt, fileExtName);
    getcwd(currentPathName,MAX_PATH);

    //Convert relative path to absolute path
    std::string originalAbsolutePath = currentPathName;
    //TODO: consider boost file system
    if (*driver == 0)
    {
        originalAbsolutePath = originalAbsolutePath + "\\" + dir;
        _InternalStringReplaceAll(originalAbsolutePath,"/","\\");
        _InternalStringReplaceAll(originalAbsolutePath,"\\\\","\\");
    }
    //Find file in original path in filename
    _InternalFindFile(originalAbsolutePath.c_str(),fileNameWithoutExt,fileExtName,outputAbsoutePath);
    
    //Find file in current working directory, recursively
    _InternalFindFile(currentPathName,fileNameWithoutExt,fileExtName,outputAbsoutePath,true);
    
    //Find path in some predefined path
    //TODO: refactor this to configurable
    const char* defaultPath1 = "../";
    const char* defaultPath2 = "E:/matlabworks";
    _InternalFindFile(defaultPath2,fileNameWithoutExt,fileExtName,outputAbsoutePath,true);
    _InternalFindFile(defaultPath1,fileNameWithoutExt,fileExtName,outputAbsoutePath,true);
    
    //Convert the path name to lower case
    _strlwr(outputAbsoutePath);

    return true;
}

void DumpErrorMsg( LPCSTR errorMsg, LPCSTR fileName )
{
    std::ofstream outputFile(fileName);
    //TODO: complex this function
    outputFile << errorMsg;
}